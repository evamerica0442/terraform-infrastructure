# Spaza POS - Setup Guide
## Your Architecture: Owner Portal + Store POS

This system implements your exact vision:
- **Owner Portal**: Web dashboard where business owners manage multiple stores
- **Store POS**: Standalone static webpage that downloads once and works offline
- **30-min sync**: Automatic syncing every 30 minutes + manual sync option
- **File-based offline storage**: More reliable than IndexedDB for poor connectivity

## Architecture Overview

```
┌─────────────────────────────────────────┐
│         OWNER PORTAL                    │
│  (Web Dashboard - Requires Internet)   │
│                                         │
│  - Register business                    │
│  - Create/manage stores                 │
│  - View sales metrics per store         │
│  - Manage products (catalog)            │
│  - View consolidated reports            │
└─────────────────────────────────────────┘
              ↕ (HTTPS/API)
┌─────────────────────────────────────────┐
│         BACKEND SERVER                  │
│  (Node.js + PostgreSQL)                 │
│                                         │
│  - Separate auth for owners vs stores   │
│  - Store username generation            │
│  - 30-min batch sync endpoint           │
│  - Deduplication logic                  │
└─────────────────────────────────────────┘
              ↕ (30-min sync)
┌─────────────────────────────────────────┐
│         STORE POS                       │
│  (Static HTML - Downloads Once)         │
│                                         │
│  - Login: storename_xxxxx + password    │
│  - Process sales offline                │
│  - Local JSON file storage              │
│  - Auto-sync every 30 minutes           │
│  - Works without internet               │
└─────────────────────────────────────────┘
```

## Quick Start

### 1. Database Setup

```bash
# Create PostgreSQL database
sudo -u postgres psql << EOF
CREATE DATABASE spaza_pos;
CREATE USER spaza_user WITH PASSWORD 'securePassword123';
GRANT ALL PRIVILEGES ON DATABASE spaza_pos TO spaza_user;
\q
EOF

# Load enhanced schema
psql -U spaza_user -d spaza_pos -f backend/schema-enhanced.sql

# Insert sample data
psql -U spaza_user -d spaza_pos -c "SELECT insert_sample_data();"
```

This creates:
- **Owner Account**: owner@spazachain.co.za / password123
- **Store 1**: sowetomain_xxxxx / password123  (auto-generated username)
- **Store 2**: alexandrabr_xxxxx / password123 (auto-generated username)

### 2. Backend Setup

```bash
cd backend
npm install

# Configure environment
cp .env.example .env
nano .env  # Update DB credentials

npm run dev
```

### 3. Frontend Setup

```bash
cd ../frontend
npm install
npm run dev
```

## Usage Flow

### For Business Owners

1. **Register on Owner Portal**
   - Go to http://localhost:3000
   - Register with email, business name, phone
   - Login to dashboard

2. **Create Stores**
   - Click "Add Store"
   - Enter: Store name, address, phone, password
   - System generates unique username: `storename_xxxxx`
   - **Save the credentials!** Give them to store manager

3. **View Metrics**
   - Dashboard shows all stores
   - Click store to see detailed sales
   - View top products, daily/weekly/monthly reports

### For Store Staff

1. **First Time Setup**
   - Visit POS URL: http://localhost:3000/pos.html
   - Enter credentials (provided by owner)
   - Page downloads and caches locally
   - Works offline from now on!

2. **Daily Operations**
   - Search products (by name, SKU, or barcode)
   - Add to cart
   - Complete sale
   - Transaction saved locally (works offline!)

3. **Syncing**
   - Automatic: Every 30 minutes when online
   - Manual: Click "Sync Now" button
   - Pending count shows unsynced transactions

## Key Features Implemented

### ✅ Owner Portal Features
- User registration and authentication
- Multi-store creation and management
- Auto-generated unique store credentials
- Sales dashboard per store
- Product catalog management

### ✅ Store POS Features
- Standalone static page (downloads once)
- Offline-first architecture
- File-based transaction storage
- 30-minute auto-sync
- Manual sync option
- Product search with autocomplete
- Multiple payment methods

---

**Your offline-first POS system is ready! 🚀**