import Dexie from 'dexie';

export const db = new Dexie('SpazaPOS');

// Define database schema
db.version(1).stores({
  // Offline transactions queue
  pendingTransactions: '++id, transaction_number, store_id, created_at, synced',
  
  // Local cache of products
  products: 'id, tenant_id, sku, name, category',
  
  // Local cache of inventory
  inventory: '[store_id+product_id], store_id, product_id, quantity',
  
  // Local cache of stores
  stores: 'id, tenant_id, name',
  
  // Sync queue for other operations
  syncQueue: '++id, entity_type, entity_id, operation, synced, created_at',
  
  // App settings and user preferences
  settings: 'key'
});

// Helper functions for offline operations

export const savePendingTransaction = async (transaction) => {
  try {
    const id = await db.pendingTransactions.add({
      ...transaction,
      created_at: new Date().toISOString(),
      synced: false
    });
    return id;
  } catch (error) {
    console.error('Error saving pending transaction:', error);
    throw error;
  }
};

export const getPendingTransactions = async () => {
  try {
    return await db.pendingTransactions
      .where('synced')
      .equals(0)
      .toArray();
  } catch (error) {
    console.error('Error fetching pending transactions:', error);
    return [];
  }
};

export const markTransactionSynced = async (id) => {
  try {
    await db.pendingTransactions.update(id, { synced: true });
  } catch (error) {
    console.error('Error marking transaction as synced:', error);
  }
};

export const cacheProducts = async (products) => {
  try {
    await db.products.bulkPut(products);
  } catch (error) {
    console.error('Error caching products:', error);
  }
};

export const getProductById = async (id) => {
  try {
    return await db.products.get(id);
  } catch (error) {
    console.error('Error fetching product:', error);
    return null;
  }
};

export const searchProducts = async (query) => {
  try {
    return await db.products
      .filter(product => 
        product.name.toLowerCase().includes(query.toLowerCase()) ||
        (product.sku && product.sku.includes(query))
      )
      .limit(20)
      .toArray();
  } catch (error) {
    console.error('Error searching products:', error);
    return [];
  }
};

export const cacheInventory = async (inventory) => {
  try {
    await db.inventory.bulkPut(inventory);
  } catch (error) {
    console.error('Error caching inventory:', error);
  }
};

export const getStoreInventory = async (storeId) => {
  try {
    return await db.inventory
      .where('store_id')
      .equals(storeId)
      .toArray();
  } catch (error) {
    console.error('Error fetching inventory:', error);
    return [];
  }
};

export const updateLocalInventory = async (storeId, productId, quantityChange) => {
  try {
    const item = await db.inventory.get([storeId, productId]);
    if (item) {
      await db.inventory.update([storeId, productId], {
        quantity: item.quantity + quantityChange,
        last_updated: new Date().toISOString()
      });
    }
  } catch (error) {
    console.error('Error updating local inventory:', error);
  }
};

export const cacheStores = async (stores) => {
  try {
    await db.stores.bulkPut(stores);
  } catch (error) {
    console.error('Error caching stores:', error);
  }
};

export const getStores = async () => {
  try {
    return await db.stores.toArray();
  } catch (error) {
    console.error('Error fetching stores:', error);
    return [];
  }
};

export const clearAllData = async () => {
  try {
    await db.delete();
    await db.open();
  } catch (error) {
    console.error('Error clearing database:', error);
  }
};

export const getSetting = async (key) => {
  try {
    const setting = await db.settings.get(key);
    return setting?.value;
  } catch (error) {
    console.error('Error getting setting:', error);
    return null;
  }
};

export const setSetting = async (key, value) => {
  try {
    await db.settings.put({ key, value });
  } catch (error) {
    console.error('Error setting setting:', error);
  }
};

export default db;
