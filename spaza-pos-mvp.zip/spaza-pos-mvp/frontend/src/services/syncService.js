import axios from 'axios';
import {
  getPendingTransactions,
  markTransactionSynced,
  cacheProducts,
  cacheInventory,
  cacheStores
} from '../db/indexeddb';

class SyncService {
  constructor() {
    this.isSyncing = false;
    this.syncInterval = null;
  }

  // Start automatic sync every 30 seconds when online
  startAutoSync() {
    if (this.syncInterval) return;
    
    this.syncInterval = setInterval(() => {
      if (navigator.onLine && !this.isSyncing) {
        this.syncPendingTransactions();
      }
    }, 30000); // 30 seconds
    
    console.log('✅ Auto-sync started');
  }

  // Stop automatic sync
  stopAutoSync() {
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = null;
      console.log('🛑 Auto-sync stopped');
    }
  }

  // Sync pending transactions to server
  async syncPendingTransactions() {
    if (this.isSyncing) {
      console.log('⏳ Sync already in progress...');
      return { success: false, message: 'Sync in progress' };
    }

    if (!navigator.onLine) {
      console.log('📴 Offline - skipping sync');
      return { success: false, message: 'Offline' };
    }

    this.isSyncing = true;

    try {
      const pending = await getPendingTransactions();
      
      if (pending.length === 0) {
        console.log('✅ No pending transactions to sync');
        this.isSyncing = false;
        return { success: true, count: 0 };
      }

      console.log(`📤 Syncing ${pending.length} pending transactions...`);

      // Prepare transactions for sync
      const transactions = pending.map(txn => ({
        transaction_number: txn.transaction_number,
        store_id: txn.store_id,
        items: txn.items,
        payment_method: txn.payment_method,
        total_amount: txn.total_amount,
        notes: txn.notes,
        transaction_date: txn.created_at
      }));

      // Send to bulk sync endpoint
      const response = await axios.post('/api/transactions/sync/bulk', {
        transactions
      });

      // Mark synced transactions
      const { results } = response.data;
      
      for (const result of results.success) {
        const pendingTxn = pending.find(
          t => t.transaction_number === result.transaction_number
        );
        if (pendingTxn) {
          await markTransactionSynced(pendingTxn.id);
        }
      }

      console.log(`✅ Synced ${results.success.length} transactions`);
      if (results.failed.length > 0) {
        console.log(`❌ Failed to sync ${results.failed.length} transactions`);
      }

      this.isSyncing = false;
      
      return {
        success: true,
        synced: results.success.length,
        failed: results.failed.length
      };
    } catch (error) {
      console.error('❌ Sync error:', error);
      this.isSyncing = false;
      
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Fetch and cache reference data
  async fetchAndCacheData(storeId) {
    if (!navigator.onLine) {
      console.log('📴 Offline - using cached data');
      return { success: false, message: 'Offline' };
    }

    try {
      console.log('📥 Fetching reference data...');

      // Fetch stores
      const storesResponse = await axios.get('/api/stores');
      if (storesResponse.data.success) {
        await cacheStores(storesResponse.data.stores);
        console.log('✅ Stores cached');
      }

      if (storeId) {
        // Fetch inventory for the store
        const inventoryResponse = await axios.get(`/api/stores/${storeId}/inventory`);
        if (inventoryResponse.data.success) {
          await cacheInventory(inventoryResponse.data.inventory);
          console.log('✅ Inventory cached');
        }
      }

      return { success: true };
    } catch (error) {
      console.error('❌ Error fetching data:', error);
      return { success: false, error: error.message };
    }
  }

  // Manual sync trigger
  async syncNow() {
    console.log('🔄 Manual sync triggered');
    const result = await this.syncPendingTransactions();
    return result;
  }
}

// Export singleton instance
export const syncService = new SyncService();

// Listen for online/offline events
window.addEventListener('online', () => {
  console.log('🌐 Connection restored - syncing...');
  syncService.syncPendingTransactions();
});

window.addEventListener('offline', () => {
  console.log('📴 Connection lost - working offline');
});

export default syncService;
