/**
 * File-Based Offline Storage for Store POS
 * 
 * This service manages offline transactions using a JSON file stored locally
 * More reliable than IndexedDB for devices with storage issues
 * Syncs every 30 minutes or on demand
 */

class OfflineStorageService {
  constructor() {
    this.storageKey = 'spaza_pos_offline_data';
    this.syncInterval = 30 * 60 * 1000; // 30 minutes
    this.syncTimer = null;
    this.isSyncing = false;
    
    this.data = {
      store: null,
      pendingTransactions: [],
      products: [],
      inventory: [],
      lastSync: null,
      syncAttempts: 0
    };
    
    // Load data from localStorage on init
    this.loadFromStorage();
  }

  // Initialize the service
  init(storeData, token) {
    this.data.store = storeData;
    this.token = token;
    this.saveToStorage();
    this.startAutoSync();
  }

  // Load data from localStorage
  loadFromStorage() {
    try {
      const stored = localStorage.getItem(this.storageKey);
      if (stored) {
        const parsed = JSON.parse(stored);
        this.data = { ...this.data, ...parsed };
        console.log('✅ Loaded offline data from storage');
        console.log(`📦 ${this.data.pendingTransactions.length} pending transactions`);
      }
    } catch (error) {
      console.error('❌ Error loading offline data:', error);
    }
  }

  // Save data to localStorage
  saveToStorage() {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(this.data));
      console.log('💾 Saved offline data to storage');
    } catch (error) {
      console.error('❌ Error saving offline data:', error);
      // If storage is full, try to clear old synced transactions
      this.cleanupStorage();
    }
  }

  // Clean up storage by removing old synced data
  cleanupStorage() {
    try {
      // Keep only pending transactions
      this.data.pendingTransactions = this.data.pendingTransactions.filter(
        t => !t.synced
      );
      this.saveToStorage();
      console.log('🧹 Cleaned up storage');
    } catch (error) {
      console.error('❌ Error cleaning storage:', error);
    }
  }

  // Export data as downloadable JSON file (backup)
  exportToFile() {
    const blob = new Blob([JSON.stringify(this.data, null, 2)], {
      type: 'application/json'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `spaza_pos_backup_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    console.log('📥 Data exported to file');
  }

  // Import data from file (restore)
  async importFromFile(file) {
    try {
      const text = await file.text();
      const imported = JSON.parse(text);
      
      // Merge pending transactions (avoid duplicates)
      const existingTxnNumbers = new Set(
        this.data.pendingTransactions.map(t => t.transaction_number)
      );
      
      const newTransactions = imported.pendingTransactions.filter(
        t => !existingTxnNumbers.has(t.transaction_number)
      );
      
      this.data.pendingTransactions.push(...newTransactions);
      this.saveToStorage();
      
      console.log(`✅ Imported ${newTransactions.length} transactions from file`);
      return { success: true, count: newTransactions.length };
    } catch (error) {
      console.error('❌ Error importing file:', error);
      return { success: false, error: error.message };
    }
  }

  // Cache products for offline use
  cacheProducts(products) {
    this.data.products = products;
    this.saveToStorage();
    console.log(`📦 Cached ${products.length} products`);
  }

  // Cache inventory for offline use
  cacheInventory(inventory) {
    this.data.inventory = inventory;
    this.saveToStorage();
    console.log(`📦 Cached inventory for ${inventory.length} products`);
  }

  // Search products (works offline)
  searchProducts(query) {
    const lowerQuery = query.toLowerCase();
    return this.data.products.filter(product =>
      product.name.toLowerCase().includes(lowerQuery) ||
      (product.sku && product.sku.toLowerCase().includes(lowerQuery)) ||
      (product.barcode && product.barcode.includes(query))
    );
  }

  // Get product inventory
  getProductInventory(productId) {
    return this.data.inventory.find(
      item => item.product_id === productId
    );
  }

  // Save a new transaction (offline)
  saveTransaction(transaction) {
    // Generate unique transaction number if not provided
    if (!transaction.transaction_number) {
      transaction.transaction_number = this.generateTransactionNumber();
    }
    
    // Add metadata
    transaction.client_created_at = new Date().toISOString();
    transaction.synced = false;
    transaction.sync_attempts = 0;
    
    // Add to pending queue
    this.data.pendingTransactions.push(transaction);
    
    // Update local inventory
    transaction.items.forEach(item => {
      this.updateLocalInventory(item.product_id, -item.quantity);
    });
    
    this.saveToStorage();
    
    console.log(`✅ Transaction ${transaction.transaction_number} saved offline`);
    
    // Try immediate sync if online
    if (navigator.onLine) {
      setTimeout(() => this.syncNow(), 1000);
    }
    
    return transaction;
  }

  // Generate unique transaction number
  generateTransactionNumber() {
    const storePrefix = this.data.store?.username?.substring(0, 4).toUpperCase() || 'STOR';
    const timestamp = Date.now();
    const random = Math.random().toString(36).substring(2, 7).toUpperCase();
    return `${storePrefix}-${timestamp}-${random}`;
  }

  // Update local inventory (optimistic update)
  updateLocalInventory(productId, quantityChange) {
    const item = this.data.inventory.find(i => i.product_id === productId);
    if (item) {
      item.quantity = parseFloat(item.quantity) + quantityChange;
      item.last_updated = new Date().toISOString();
    }
  }

  // Get pending transactions count
  getPendingCount() {
    return this.data.pendingTransactions.filter(t => !t.synced).length;
  }

  // Start automatic sync
  startAutoSync() {
    if (this.syncTimer) return;
    
    this.syncTimer = setInterval(() => {
      if (navigator.onLine && !this.isSyncing) {
        this.syncNow();
      }
    }, this.syncInterval);
    
    console.log(`⏰ Auto-sync started (every ${this.syncInterval / 60000} minutes)`);
    
    // Immediate sync if online
    if (navigator.onLine) {
      setTimeout(() => this.syncNow(), 2000);
    }
  }

  // Stop automatic sync
  stopAutoSync() {
    if (this.syncTimer) {
      clearInterval(this.syncTimer);
      this.syncTimer = null;
      console.log('🛑 Auto-sync stopped');
    }
  }

  // Sync now (manual trigger)
  async syncNow() {
    if (this.isSyncing) {
      console.log('⏳ Sync already in progress...');
      return { success: false, message: 'Sync in progress' };
    }

    if (!navigator.onLine) {
      console.log('📴 Offline - cannot sync');
      return { success: false, message: 'Offline' };
    }

    const pending = this.data.pendingTransactions.filter(t => !t.synced);
    
    if (pending.length === 0) {
      console.log('✅ No pending transactions to sync');
      return { success: true, count: 0 };
    }

    this.isSyncing = true;
    this.data.syncAttempts++;

    try {
      console.log(`📤 Syncing ${pending.length} pending transactions...`);

      const response = await fetch('/api/pos/sync', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.token}`
        },
        body: JSON.stringify({
          transactions: pending.map(t => ({
            transaction_number: t.transaction_number,
            items: t.items,
            payment_method: t.payment_method,
            total_amount: t.total_amount,
            notes: t.notes,
            staff_id: t.staff_id,
            transaction_date: t.client_created_at
          }))
        })
      });

      if (!response.ok) {
        throw new Error(`Sync failed: ${response.statusText}`);
      }

      const result = await response.json();

      // Mark synced transactions
      result.synced.forEach(syncedTxn => {
        const txn = this.data.pendingTransactions.find(
          t => t.transaction_number === syncedTxn.transaction_number
        );
        if (txn) {
          txn.synced = true;
          txn.synced_at = new Date().toISOString();
        }
      });

      // Update sync attempts for failed transactions
      result.failed.forEach(failedTxn => {
        const txn = this.data.pendingTransactions.find(
          t => t.transaction_number === failedTxn.transaction_number
        );
        if (txn) {
          txn.sync_attempts = (txn.sync_attempts || 0) + 1;
        }
      });

      this.data.lastSync = new Date().toISOString();
      this.saveToStorage();

      console.log(`✅ Synced ${result.synced.length} transactions`);
      if (result.failed.length > 0) {
        console.log(`❌ Failed to sync ${result.failed.length} transactions`);
      }

      this.isSyncing = false;

      return {
        success: true,
        synced: result.synced.length,
        failed: result.failed.length,
        lastSync: this.data.lastSync
      };
    } catch (error) {
      console.error('❌ Sync error:', error);
      this.isSyncing = false;
      
      // Increment sync attempts for all pending
      pending.forEach(txn => {
        txn.sync_attempts = (txn.sync_attempts || 0) + 1;
      });
      this.saveToStorage();

      return {
        success: false,
        error: error.message
      };
    }
  }

  // Refresh products and inventory from server
  async refreshData() {
    if (!navigator.onLine) {
      console.log('📴 Offline - using cached data');
      return { success: false, message: 'Offline' };
    }

    try {
      console.log('📥 Refreshing data from server...');

      // Fetch products
      const productsResponse = await fetch('/api/pos/products', {
        headers: {
          'Authorization': `Bearer ${this.token}`
        }
      });

      if (productsResponse.ok) {
        const productsData = await productsResponse.json();
        this.cacheProducts(productsData.products);
      }

      // Fetch inventory
      const inventoryResponse = await fetch('/api/pos/inventory', {
        headers: {
          'Authorization': `Bearer ${this.token}`
        }
      });

      if (inventoryResponse.ok) {
        const inventoryData = await inventoryResponse.json();
        this.cacheInventory(inventoryData.inventory);
      }

      this.data.lastSync = new Date().toISOString();
      this.saveToStorage();

      console.log('✅ Data refreshed successfully');
      return { success: true };
    } catch (error) {
      console.error('❌ Error refreshing data:', error);
      return { success: false, error: error.message };
    }
  }

  // Get sync status
  getSyncStatus() {
    const pending = this.getPendingCount();
    return {
      isOnline: navigator.onLine,
      isSyncing: this.isSyncing,
      pendingTransactions: pending,
      lastSync: this.data.lastSync,
      totalSyncAttempts: this.data.syncAttempts,
      productsCount: this.data.products.length,
      inventoryCount: this.data.inventory.length
    };
  }

  // Clear all data (logout)
  clearAllData() {
    this.stopAutoSync();
    localStorage.removeItem(this.storageKey);
    this.data = {
      store: null,
      pendingTransactions: [],
      products: [],
      inventory: [],
      lastSync: null,
      syncAttempts: 0
    };
    console.log('🗑️ All offline data cleared');
  }
}

// Export singleton instance
export const offlineStorage = new OfflineStorageService();

// Listen for online/offline events
window.addEventListener('online', () => {
  console.log('🌐 Connection restored');
  offlineStorage.syncNow();
});

window.addEventListener('offline', () => {
  console.log('📴 Connection lost - working offline');
});

// Sync before page unload if there are pending transactions
window.addEventListener('beforeunload', (e) => {
  const pending = offlineStorage.getPendingCount();
  if (pending > 0 && navigator.onLine) {
    e.preventDefault();
    e.returnValue = `You have ${pending} unsaved transactions. Are you sure you want to leave?`;
  }
});

export default offlineStorage;
