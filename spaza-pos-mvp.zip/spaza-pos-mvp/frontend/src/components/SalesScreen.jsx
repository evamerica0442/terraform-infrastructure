import React, { useState, useEffect } from 'react';
import { savePendingTransaction, searchProducts, updateLocalInventory } from '../db/indexeddb';
import { syncService } from '../services/syncService';
import '../styles/SalesScreen.css';

const SalesScreen = ({ currentStore, currentUser }) => {
  const [cart, setCart] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [total, setTotal] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    // Update online status
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    // Calculate total whenever cart changes
    const newTotal = cart.reduce((sum, item) => sum + item.subtotal, 0);
    setTotal(newTotal);
  }, [cart]);

  const handleSearch = async (query) => {
    setSearchQuery(query);
    
    if (query.length < 2) {
      setSearchResults([]);
      return;
    }
    
    const results = await searchProducts(query);
    setSearchResults(results);
  };

  const addToCart = (product) => {
    const existingItem = cart.find(item => item.product_id === product.id);
    
    if (existingItem) {
      // Increase quantity
      setCart(cart.map(item =>
        item.product_id === product.id
          ? {
              ...item,
              quantity: item.quantity + 1,
              subtotal: (item.quantity + 1) * item.unit_price
            }
          : item
      ));
    } else {
      // Add new item
      setCart([
        ...cart,
        {
          product_id: product.id,
          product_name: product.name,
          sku: product.sku,
          quantity: 1,
          unit_price: product.selling_price,
          subtotal: product.selling_price,
          discount: 0
        }
      ]);
    }
    
    setSearchQuery('');
    setSearchResults([]);
  };

  const updateQuantity = (productId, newQuantity) => {
    if (newQuantity <= 0) {
      removeFromCart(productId);
      return;
    }
    
    setCart(cart.map(item =>
      item.product_id === productId
        ? {
            ...item,
            quantity: newQuantity,
            subtotal: newQuantity * item.unit_price
          }
        : item
    ));
  };

  const removeFromCart = (productId) => {
    setCart(cart.filter(item => item.product_id !== productId));
  };

  const completeSale = async () => {
    if (cart.length === 0) {
      alert('Cart is empty');
      return;
    }
    
    if (!currentStore) {
      alert('No store selected');
      return;
    }
    
    setIsProcessing(true);
    
    try {
      const transaction = {
        transaction_number: `TXN-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        store_id: currentStore.id,
        items: cart,
        payment_method: paymentMethod,
        total_amount: total,
        notes: '',
        created_at: new Date().toISOString()
      };
      
      // Save to IndexedDB (works offline)
      await savePendingTransaction(transaction);
      
      // Update local inventory
      for (const item of cart) {
        await updateLocalInventory(currentStore.id, item.product_id, -item.quantity);
      }
      
      // Try to sync immediately if online
      if (isOnline) {
        syncService.syncNow();
      }
      
      // Clear cart
      setCart([]);
      setTotal(0);
      
      alert(`Sale completed! ${isOnline ? 'Synced to server' : 'Saved offline - will sync when online'}`);
    } catch (error) {
      console.error('Error completing sale:', error);
      alert('Error processing sale. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="sales-screen">
      <div className="sales-header">
        <h2>Point of Sale</h2>
        <div className="status-indicators">
          <span className={`status ${isOnline ? 'online' : 'offline'}`}>
            {isOnline ? '🌐 Online' : '📴 Offline'}
          </span>
          {currentStore && (
            <span className="store-name">📍 {currentStore.name}</span>
          )}
        </div>
      </div>

      <div className="sales-content">
        <div className="search-section">
          <input
            type="text"
            className="search-input"
            placeholder="Search products (name or SKU)..."
            value={searchQuery}
            onChange={(e) => handleSearch(e.target.value)}
            autoFocus
          />
          
          {searchResults.length > 0 && (
            <div className="search-results">
              {searchResults.map(product => (
                <div
                  key={product.id}
                  className="search-result-item"
                  onClick={() => addToCart(product)}
                >
                  <div className="product-info">
                    <strong>{product.name}</strong>
                    {product.sku && <span className="sku">SKU: {product.sku}</span>}
                  </div>
                  <div className="product-price">R {product.selling_price.toFixed(2)}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="cart-section">
          <h3>Cart</h3>
          {cart.length === 0 ? (
            <div className="empty-cart">
              <p>Cart is empty</p>
              <p>Search and add products to start a sale</p>
            </div>
          ) : (
            <div className="cart-items">
              {cart.map(item => (
                <div key={item.product_id} className="cart-item">
                  <div className="item-details">
                    <strong>{item.product_name}</strong>
                    <span className="item-price">R {item.unit_price.toFixed(2)} each</span>
                  </div>
                  <div className="item-controls">
                    <button
                      onClick={() => updateQuantity(item.product_id, item.quantity - 1)}
                      className="btn-quantity"
                    >
                      -
                    </button>
                    <input
                      type="number"
                      value={item.quantity}
                      onChange={(e) => updateQuantity(item.product_id, parseFloat(e.target.value))}
                      className="quantity-input"
                      min="0"
                      step="0.1"
                    />
                    <button
                      onClick={() => updateQuantity(item.product_id, item.quantity + 1)}
                      className="btn-quantity"
                    >
                      +
                    </button>
                    <button
                      onClick={() => removeFromCart(item.product_id)}
                      className="btn-remove"
                    >
                      ✕
                    </button>
                  </div>
                  <div className="item-subtotal">
                    R {item.subtotal.toFixed(2)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="checkout-section">
          <div className="total-display">
            <span className="total-label">Total:</span>
            <span className="total-amount">R {total.toFixed(2)}</span>
          </div>

          <div className="payment-methods">
            <label>Payment Method:</label>
            <div className="payment-options">
              <button
                className={`payment-btn ${paymentMethod === 'cash' ? 'active' : ''}`}
                onClick={() => setPaymentMethod('cash')}
              >
                💵 Cash
              </button>
              <button
                className={`payment-btn ${paymentMethod === 'card' ? 'active' : ''}`}
                onClick={() => setPaymentMethod('card')}
              >
                💳 Card
              </button>
              <button
                className={`payment-btn ${paymentMethod === 'mobile_money' ? 'active' : ''}`}
                onClick={() => setPaymentMethod('mobile_money')}
              >
                📱 Mobile Money
              </button>
            </div>
          </div>

          <button
            className="btn-complete-sale"
            onClick={completeSale}
            disabled={cart.length === 0 || isProcessing}
          >
            {isProcessing ? 'Processing...' : 'Complete Sale'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default SalesScreen;
