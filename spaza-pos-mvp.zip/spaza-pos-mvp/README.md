# Spaza POS - Multitenant Point of Sale System

A modern, offline-first Point of Sale system designed specifically for Spaza shops in South Africa. Built with multitenancy, offline functionality, and multi-store management at its core.

## 🌟 Key Features

- **Multitenant Architecture**: Secure data isolation per business using PostgreSQL Row-Level Security
- **Offline-First**: Full offline functionality with automatic sync when connection is restored
- **Multi-Store Management**: Manage multiple store locations from a single account
- **Progressive Web App (PWA)**: Installable on any device, works like a native app
- **Real-time Inventory**: Track stock levels across all stores
- **Sales Processing**: Fast checkout with multiple payment methods (cash, card, mobile money)
- **Automatic Sync**: Background synchronization of offline transactions
- **Mobile-Optimized**: Responsive design works on phones, tablets, and desktops

## 🏗️ Architecture

### Tech Stack

**Backend:**
- Node.js + Express
- PostgreSQL with Row-Level Security (RLS)
- JWT Authentication
- RESTful API

**Frontend:**
- React 18 + Vite
- IndexedDB (Dexie) for offline storage
- Service Workers for PWA functionality
- Zustand for state management

### Database Schema

The system uses a hierarchical multitenant model:
```
Tenants (Businesses)
  ├─ Users (Owners, Managers, Cashiers)
  ├─ Stores (Multiple locations)
  │   └─ Inventory (Stock per store)
  ├─ Products (Shared across stores)
  └─ Transactions (Sales records)
```

## 📋 Prerequisites

- Node.js 18+ and npm
- PostgreSQL 14+
- Git

## 🚀 Getting Started

### 1. Clone the Repository

```bash
git clone <your-repo-url>
cd spaza-pos-mvp
```

### 2. Database Setup

```bash
# Install PostgreSQL (Ubuntu/Debian)
sudo apt update
sudo apt install postgresql postgresql-contrib

# Start PostgreSQL service
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Create database and user
sudo -u postgres psql
```

In PostgreSQL shell:
```sql
CREATE DATABASE spaza_pos;
CREATE USER spaza_user WITH PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE spaza_pos TO spaza_user;
\q
```

Run the schema:
```bash
psql -U spaza_user -d spaza_pos -f backend/schema.sql
```

### 3. Backend Setup

```bash
cd backend

# Install dependencies
npm install

# Create environment file
cp .env.example .env

# Edit .env with your database credentials
nano .env
```

Update `.env`:
```env
DB_HOST=localhost
DB_PORT=5432
DB_USER=spaza_user
DB_PASSWORD=your_secure_password
DB_NAME=spaza_pos
JWT_SECRET=generate-a-strong-random-secret-key
PORT=3001
NODE_ENV=development
CORS_ORIGIN=http://localhost:3000
```

Start the backend:
```bash
npm run dev
```

The API will be running at `http://localhost:3001`

### 4. Frontend Setup

```bash
cd ../frontend

# Install dependencies
npm install

# Start development server
npm run dev
```

The app will be running at `http://localhost:3000`

## 🗄️ Database Sample Data

To insert sample data for testing:

```sql
-- Connect to database
psql -U spaza_user -d spaza_pos

-- Run the sample data function
SELECT insert_sample_data();
```

This creates:
- Sample tenant: "Demo Spaza Chain"
- Sample store: "Main Street Spaza"
- Sample user: owner@spaza.co.za (password: password123)

## 🔐 Authentication Flow

1. **Registration**: Create tenant account (business)
2. **Login**: Obtain JWT token
3. **Token Usage**: Include in Authorization header: `Bearer <token>`
4. **Store Selection**: Choose which store to operate from
5. **POS Operations**: Process sales with offline support

## 📱 Offline Functionality

### How It Works

1. **IndexedDB Storage**: All data cached locally in browser
2. **Offline Detection**: App detects connectivity status
3. **Queue System**: Offline transactions saved to local queue
4. **Auto-Sync**: When online, automatically syncs pending transactions
5. **Conflict Resolution**: Server validates and deduplicates transactions

### Testing Offline Mode

1. Open Chrome DevTools (F12)
2. Go to Network tab
3. Select "Offline" from throttling dropdown
4. Process sales - they'll be saved locally
5. Return to "Online" - watch automatic sync

## 🏪 Multi-Store Management

### Store Operations

- Each tenant can have multiple stores
- Inventory tracked separately per store
- Sales transactions linked to specific stores
- Centralized product catalog shared across stores

### API Endpoints

```
GET    /api/stores                    - List all stores
GET    /api/stores/:id                - Get store details
POST   /api/stores                    - Create new store
PUT    /api/stores/:id                - Update store
GET    /api/stores/:id/inventory      - Get store inventory
```

## 💳 Sales Processing

### Transaction Flow

1. Search and add products to cart
2. Adjust quantities as needed
3. Select payment method
4. Complete sale
5. Transaction saved (offline-capable)
6. Inventory automatically updated
7. Sync to server when online

### API Endpoints

```
GET    /api/transactions/store/:storeId  - Get transactions
GET    /api/transactions/:id             - Get transaction details
POST   /api/transactions                 - Create transaction
POST   /api/transactions/sync/bulk       - Bulk sync offline transactions
```

## 🚢 Deployment

### Backend Deployment (Ubuntu Server)

```bash
# Install Node.js and PostgreSQL
sudo apt update
sudo apt install nodejs npm postgresql

# Clone repository
git clone <your-repo-url>
cd spaza-pos-mvp/backend

# Install dependencies
npm install

# Setup environment
cp .env.example .env
nano .env  # Configure production settings

# Setup database
sudo -u postgres createdb spaza_pos
psql -U postgres -d spaza_pos -f schema.sql

# Install PM2 for process management
sudo npm install -g pm2

# Start application
pm2 start src/server.js --name spaza-pos-api
pm2 save
pm2 startup
```

### Frontend Deployment

```bash
cd ../frontend

# Install dependencies
npm install

# Build for production
npm run build

# Deploy 'dist' folder to:
# - Netlify
# - Vercel
# - Your own web server (nginx/apache)
```

### Environment Variables for Production

**Backend:**
```env
NODE_ENV=production
DB_HOST=your-db-host
DB_USER=your-db-user
DB_PASSWORD=strong-password
JWT_SECRET=very-strong-random-secret
CORS_ORIGIN=https://your-frontend-domain.com
```

**Frontend (set in deployment platform):**
```env
VITE_API_URL=https://your-api-domain.com
```

## 🔧 Development

### Project Structure

```
spaza-pos-mvp/
├── backend/
│   ├── src/
│   │   ├── db/
│   │   │   └── config.js          # Database connection
│   │   ├── middleware/
│   │   │   └── auth.js            # Authentication middleware
│   │   ├── routes/
│   │   │   ├── stores.js          # Store management routes
│   │   │   └── transactions.js    # Transaction routes
│   │   └── server.js              # Express app
│   ├── schema.sql                 # Database schema
│   └── package.json
│
└── frontend/
    ├── src/
    │   ├── components/
    │   │   └── SalesScreen.jsx    # Main POS interface
    │   ├── db/
    │   │   └── indexeddb.js       # Offline storage
    │   ├── services/
    │   │   └── syncService.js     # Sync management
    │   └── styles/
    │       └── SalesScreen.css
    ├── vite.config.js             # Vite + PWA config
    └── package.json
```

### Adding Features

**New API Route:**
1. Create route file in `backend/src/routes/`
2. Add authentication middleware
3. Implement tenant isolation
4. Register in `server.js`

**New Frontend Component:**
1. Create component in `frontend/src/components/`
2. Add offline support if needed
3. Update IndexedDB schema if storing data
4. Style in corresponding CSS file

## 🔍 Troubleshooting

### Database Connection Issues
```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Check logs
sudo tail -f /var/log/postgresql/postgresql-*.log
```

### Sync Not Working
- Check browser console for errors
- Verify network connectivity
- Check JWT token validity
- Review server logs

### Offline Storage Full
```javascript
// Clear IndexedDB (in browser console)
indexedDB.deleteDatabase('SpazaPOS');
```

## 📊 Monitoring

### Key Metrics to Track
- Pending transaction queue size
- Sync success/failure rate
- API response times
- Database connection pool utilization

### Logging
Backend uses console logging. For production, integrate:
- Winston for structured logging
- Sentry for error tracking
- PM2 logs for process monitoring

## 🔐 Security Considerations

1. **Row-Level Security (RLS)**: Database-level tenant isolation
2. **JWT Tokens**: Secure authentication with expiration
3. **Input Validation**: Sanitize all user inputs
4. **HTTPS Only**: Use SSL in production
5. **Rate Limiting**: Prevent API abuse
6. **Password Hashing**: bcrypt with salt rounds

## 📈 Next Steps / Roadmap

- [ ] Product management UI
- [ ] Inventory adjustment workflows
- [ ] Reporting and analytics dashboard
- [ ] Mobile money API integration (Yoco, SnapScan)
- [ ] Receipt printing
- [ ] Barcode scanning
- [ ] User management interface
- [ ] Role-based permissions UI
- [ ] Multi-language support (Zulu, Xhosa, Afrikaans)
- [ ] SMS notifications for low stock
- [ ] Customer loyalty program

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

## 📝 License

This project is licensed under the MIT License.

## 💬 Support

For questions and support:
- Open an issue on GitHub
- Email: support@spazapos.co.za (example)

## 🙏 Acknowledgments

Built for the Spaza shop community in South Africa to modernize operations and improve business efficiency.

---

**Built with ❤️ for South African entrepreneurs**
