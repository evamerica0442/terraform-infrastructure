# Spaza POS System Architecture

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      CLIENT LAYER                           │
│  ┌────────────────────────────────────────────────────┐    │
│  │  React PWA (Progressive Web App)                   │    │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────┐ │    │
│  │  │ SalesScreen  │  │   Stores     │  │ Reports  │ │    │
│  │  │  Component   │  │  Management  │  │  (Future)│ │    │
│  │  └──────────────┘  └──────────────┘  └──────────┘ │    │
│  │                                                     │    │
│  │  ┌─────────────────────────────────────────────┐  │    │
│  │  │      State Management (Zustand)             │  │    │
│  │  └─────────────────────────────────────────────┘  │    │
│  └────────────────────────────────────────────────────┘    │
│                         ↕                                   │
│  ┌────────────────────────────────────────────────────┐    │
│  │           Service Worker (PWA)                     │    │
│  │  - Caching strategy                                │    │
│  │  - Background sync                                 │    │
│  │  - Offline detection                               │    │
│  └────────────────────────────────────────────────────┘    │
│                         ↕                                   │
│  ┌────────────────────────────────────────────────────┐    │
│  │      IndexedDB (Offline Storage - Dexie)           │    │
│  │  ┌────────────┐ ┌─────────────┐ ┌──────────────┐  │    │
│  │  │ Pending    │ │  Products   │ │  Inventory   │  │    │
│  │  │Transactions│ │   Cache     │ │    Cache     │  │    │
│  │  └────────────┘ └─────────────┘ └──────────────┘  │    │
│  └────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
                              ↕
                    HTTPS/REST API (JWT Auth)
                              ↕
┌─────────────────────────────────────────────────────────────┐
│                      SERVER LAYER                           │
│  ┌────────────────────────────────────────────────────┐    │
│  │        Express.js API Server                       │    │
│  │  ┌──────────────────────────────────────────────┐ │    │
│  │  │  Middleware Stack                            │ │    │
│  │  │  - CORS                                      │ │    │
│  │  │  - Helmet (Security)                        │ │    │
│  │  │  - Rate Limiting                            │ │    │
│  │  │  - JWT Authentication                       │ │    │
│  │  └──────────────────────────────────────────────┘ │    │
│  │                                                     │    │
│  │  ┌──────────────────────────────────────────────┐ │    │
│  │  │  API Routes                                  │ │    │
│  │  │  ┌──────────────┐  ┌────────────────────┐  │ │    │
│  │  │  │   /stores    │  │  /transactions     │  │ │    │
│  │  │  │              │  │  - GET, POST       │  │ │    │
│  │  │  │  - CRUD ops  │  │  - /sync/bulk      │  │ │    │
│  │  │  │  - Inventory │  │  (offline sync)    │  │ │    │
│  │  │  └──────────────┘  └────────────────────┘  │ │    │
│  │  └──────────────────────────────────────────────┘ │    │
│  └────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
                              ↕
┌─────────────────────────────────────────────────────────────┐
│                    DATABASE LAYER                           │
│  ┌────────────────────────────────────────────────────┐    │
│  │          PostgreSQL 14+                            │    │
│  │  ┌──────────────────────────────────────────────┐ │    │
│  │  │  Row-Level Security (RLS) Policies           │ │    │
│  │  │  - Tenant isolation at database level        │ │    │
│  │  │  - current_tenant_id() function              │ │    │
│  │  └──────────────────────────────────────────────┘ │    │
│  │                                                     │    │
│  │  ┌──────────────────────────────────────────────┐ │    │
│  │  │  Tables (with tenant_id on all)              │ │    │
│  │  │                                               │ │    │
│  │  │  tenants → users                             │ │    │
│  │  │         → stores → inventory                 │ │    │
│  │  │         → products                           │ │    │
│  │  │         → transactions → transaction_items   │ │    │
│  │  │         → sync_queue                         │ │    │
│  │  └──────────────────────────────────────────────┘ │    │
│  └────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

## Data Flow: Offline Sale

```
1. User adds products to cart (IndexedDB)
   ↓
2. User completes sale
   ↓
3. Transaction saved to pendingTransactions (IndexedDB)
   ↓
4. Local inventory updated (IndexedDB)
   ↓
5. [OFFLINE] Transaction queued for sync
   ↓
6. [BACK ONLINE] Sync service detects connection
   ↓
7. POST /api/transactions/sync/bulk
   ↓
8. Server validates & deduplicates
   ↓
9. Transaction inserted into PostgreSQL
   ↓
10. Server inventory updated
    ↓
11. Response to client
    ↓
12. Mark transaction as synced (IndexedDB)
```

## Multi-Tenant Isolation

```
Request Flow with Tenant Isolation:

1. Client sends request with JWT token
   Authorization: Bearer <token>
   ↓
2. Express middleware validates token
   Extract: { userId, tenantId, role }
   ↓
3. Database connection established
   ↓
4. Set session context:
   SET LOCAL app.current_tenant_id = '<tenantId>'
   ↓
5. Query executed
   RLS policy filters: WHERE tenant_id = current_tenant_id()
   ↓
6. Only tenant's data returned
```

## Security Layers

```
┌────────────────────────────────────┐
│  1. HTTPS/TLS Encryption           │
└────────────────────────────────────┘
              ↓
┌────────────────────────────────────┐
│  2. JWT Token Authentication       │
│     - Signed with secret           │
│     - Expiration enforced          │
└────────────────────────────────────┘
              ↓
┌────────────────────────────────────┐
│  3. Role-Based Access Control      │
│     - Owner, Manager, Cashier      │
└────────────────────────────────────┘
              ↓
┌────────────────────────────────────┐
│  4. Rate Limiting                  │
│     - Prevent API abuse            │
└────────────────────────────────────┘
              ↓
┌────────────────────────────────────┐
│  5. Row-Level Security (RLS)       │
│     - Database-level isolation     │
└────────────────────────────────────┘
              ↓
┌────────────────────────────────────┐
│  6. Input Validation               │
│     - SQL injection prevention     │
└────────────────────────────────────┘
```

## Offline Sync Strategy

```
┌─────────────────────────────────────────┐
│  Client Creates Transaction Offline     │
│  - Generate unique transaction_number   │
│  - Save to IndexedDB                    │
│  - Update local inventory               │
└─────────────────────────────────────────┘
                  ↓
┌─────────────────────────────────────────┐
│  Sync Service (Every 30s or on demand)  │
│  - Check navigator.onLine               │
│  - Get pending transactions             │
│  - Batch sync to server                 │
└─────────────────────────────────────────┘
                  ↓
┌─────────────────────────────────────────┐
│  Server Processing                      │
│  - Check if transaction_number exists   │
│  - If exists: skip (already synced)     │
│  - If new: process transaction          │
│  - Return success/failure per txn       │
└─────────────────────────────────────────┘
                  ↓
┌─────────────────────────────────────────┐
│  Client Handles Response                │
│  - Mark synced transactions             │
│  - Retry failed transactions            │
│  - Update UI status                     │
└─────────────────────────────────────────┘
```

## Scalability Considerations

### Current Architecture (MVP)
- Single PostgreSQL instance
- Single Node.js server
- Supports: ~100 concurrent users, ~50 stores

### Future Scaling Path

```
┌────────────────────────────────────┐
│  Load Balancer (nginx/HAProxy)     │
└────────────────────────────────────┘
         ↓            ↓           ↓
   ┌─────────┐  ┌─────────┐  ┌─────────┐
   │ Node 1  │  │ Node 2  │  │ Node 3  │
   └─────────┘  └─────────┘  └─────────┘
                     ↓
         ┌───────────────────────┐
         │  PostgreSQL Primary   │
         └───────────────────────┘
                ↓           ↓
         ┌──────────┐  ┌──────────┐
         │ Replica 1│  │ Replica 2│
         └──────────┘  └──────────┘
```

Optimizations:
- Redis for session storage
- Read replicas for reports
- CDN for static assets
- Database connection pooling
- Horizontal scaling of API servers

## Technology Choices - Rationale

| Component | Technology | Why? |
|-----------|-----------|------|
| Database | PostgreSQL | RLS for tenant isolation, ACID compliance, JSON support |
| Backend | Node.js/Express | Fast I/O, large ecosystem, JavaScript consistency |
| Frontend | React + Vite | Component reusability, fast builds, PWA support |
| Offline Storage | IndexedDB (Dexie) | Large storage capacity, structured data, async API |
| State Management | Zustand | Lightweight, simple API, great for offline state |
| PWA | Vite-PWA | Easy service worker setup, offline-first patterns |
| Auth | JWT | Stateless, scalable, works well with multitenancy |

---

This architecture prioritizes:
1. **Offline-first** - Works without internet
2. **Security** - Multi-layered tenant isolation
3. **Simplicity** - Easy to understand and maintain
4. **Scalability** - Can grow with business needs
5. **Developer Experience** - Modern tools, clear patterns
