# Quick Start Guide - Spaza POS

Get your POS system running in under 10 minutes!

## Prerequisites Check

```bash
# Check Node.js (need 18+)
node --version

# Check PostgreSQL (need 14+)
psql --version

# If missing, install:
# Ubuntu/Debian:
sudo apt install nodejs npm postgresql
```

## 5-Minute Setup

### 1. Database (2 minutes)

```bash
# Create database
sudo -u postgres psql -c "CREATE DATABASE spaza_pos;"
sudo -u postgres psql -c "CREATE USER spaza_user WITH PASSWORD 'dev123';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE spaza_pos TO spaza_user;"

# Load schema
cd spaza-pos-mvp/backend
psql -U spaza_user -d spaza_pos -f schema.sql

# Insert test data
psql -U spaza_user -d spaza_pos -c "SELECT insert_sample_data();"
```

### 2. Backend (1 minute)

```bash
cd backend
npm install
cp .env.example .env

# Start server
npm run dev
# Should see: "🚀 Spaza POS API server running on port 3001"
```

### 3. Frontend (1 minute)

```bash
# New terminal
cd frontend
npm install

# Start app
npm run dev
# Should see: "Local: http://localhost:3000"
```

### 4. Test Login (1 minute)

1. Open http://localhost:3000
2. Login with:
   - Email: `owner@spaza.co.za`
   - Password: `password123`

## Test Offline Mode

1. Open Chrome DevTools (F12)
2. Network tab → Select "Offline"
3. Add products to cart
4. Complete sale
5. Go back "Online"
6. Watch it sync automatically! 🎉

## Common Issues

**Can't connect to database?**
```bash
sudo systemctl start postgresql
```

**Port 3000 already in use?**
```bash
# Kill process on port 3000
sudo lsof -t -i:3000 | xargs kill -9
```

**npm install fails?**
```bash
# Clear npm cache
npm cache clean --force
rm -rf node_modules package-lock.json
npm install
```

## What's Next?

- Read the full README.md for deployment
- Add your own products and stores
- Customize for your business needs
- Deploy to production!

## Need Help?

Check the main README.md for:
- Full documentation
- API reference
- Deployment guides
- Troubleshooting

---

**You're ready to process sales! 🚀**
