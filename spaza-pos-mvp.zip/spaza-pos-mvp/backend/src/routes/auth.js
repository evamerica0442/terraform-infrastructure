const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db/config');

// OWNER PORTAL AUTHENTICATION

// Owner registration
router.post('/owner/register', async (req, res) => {
  const { email, password, full_name, business_name, phone } = req.body;
  
  if (!email || !password || !full_name || !business_name) {
    return res.status(400).json({ 
      error: 'Email, password, full name, and business name are required' 
    });
  }
  
  try {
    // Check if owner already exists
    const existing = await db.query(
      'SELECT id FROM owners WHERE email = $1',
      [email.toLowerCase()]
    );
    
    if (existing.rows.length > 0) {
      return res.status(400).json({ error: 'Email already registered' });
    }
    
    // Hash password
    const salt = await bcrypt.genSalt(10);
    const password_hash = await bcrypt.hash(password, salt);
    
    // Create owner
    const result = await db.query(
      `INSERT INTO owners (email, password_hash, full_name, business_name, phone)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, email, full_name, business_name, created_at`,
      [email.toLowerCase(), password_hash, full_name, business_name, phone]
    );
    
    const owner = result.rows[0];
    
    // Generate JWT token
    const token = jwt.sign(
      { 
        ownerId: owner.id, 
        email: owner.email,
        type: 'owner'
      },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );
    
    res.status(201).json({
      success: true,
      message: 'Owner account created successfully',
      token,
      owner: {
        id: owner.id,
        email: owner.email,
        full_name: owner.full_name,
        business_name: owner.business_name
      }
    });
  } catch (error) {
    console.error('Owner registration error:', error);
    res.status(500).json({ error: 'Failed to create owner account' });
  }
});

// Owner login
router.post('/owner/login', async (req, res) => {
  const { email, password } = req.body;
  
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }
  
  try {
    const result = await db.query(
      'SELECT * FROM owners WHERE email = $1 AND is_active = true',
      [email.toLowerCase()]
    );
    
    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    
    const owner = result.rows[0];
    
    // Verify password
    const validPassword = await bcrypt.compare(password, owner.password_hash);
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    
    // Generate JWT token
    const token = jwt.sign(
      { 
        ownerId: owner.id, 
        email: owner.email,
        type: 'owner'
      },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );
    
    res.json({
      success: true,
      token,
      owner: {
        id: owner.id,
        email: owner.email,
        full_name: owner.full_name,
        business_name: owner.business_name,
        subscription_tier: owner.subscription_tier
      }
    });
  } catch (error) {
    console.error('Owner login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
});

// STORE POS AUTHENTICATION

// Store login (for POS system)
router.post('/store/login', async (req, res) => {
  const { username, password } = req.body;
  
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }
  
  try {
    const result = await db.query(
      `SELECT s.*, o.business_name, o.id as owner_id
       FROM stores s
       JOIN owners o ON s.owner_id = o.id
       WHERE s.store_username = $1 AND s.is_active = true AND o.is_active = true`,
      [username.toLowerCase()]
    );
    
    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid username or password' });
    }
    
    const store = result.rows[0];
    
    // Verify password
    const validPassword = await bcrypt.compare(password, store.store_password_hash);
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid username or password' });
    }
    
    // Generate JWT token for store
    const token = jwt.sign(
      { 
        storeId: store.id,
        ownerId: store.owner_id,
        storeUsername: store.store_username,
        type: 'store'
      },
      process.env.JWT_SECRET,
      { expiresIn: '30d' } // Longer expiry for POS devices
    );
    
    res.json({
      success: true,
      token,
      store: {
        id: store.id,
        name: store.store_name,
        username: store.store_username,
        business_name: store.business_name,
        address: store.address,
        phone: store.phone,
        last_sync_at: store.last_sync_at
      }
    });
  } catch (error) {
    console.error('Store login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
});

// Staff quick login (PIN-based for cashiers)
router.post('/store/staff/login', async (req, res) => {
  const { store_id, staff_code } = req.body;
  
  if (!store_id || !staff_code) {
    return res.status(400).json({ error: 'Store ID and staff code are required' });
  }
  
  try {
    const result = await db.query(
      `SELECT sf.*, s.store_name, s.owner_id
       FROM store_staff sf
       JOIN stores s ON sf.store_id = s.id
       WHERE sf.store_id = $1 AND sf.staff_code = $2 AND sf.is_active = true`,
      [store_id, staff_code]
    );
    
    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid staff code' });
    }
    
    const staff = result.rows[0];
    
    res.json({
      success: true,
      staff: {
        id: staff.id,
        name: staff.staff_name,
        role: staff.role,
        store_id: staff.store_id,
        store_name: staff.store_name
      }
    });
  } catch (error) {
    console.error('Staff login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
});

// Token verification middleware (export for use in other routes)
const authenticateOwner = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }
  
  jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    
    if (decoded.type !== 'owner') {
      return res.status(403).json({ error: 'Owner access required' });
    }
    
    req.owner = decoded;
    next();
  });
};

const authenticateStore = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }
  
  jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    
    if (decoded.type !== 'store') {
      return res.status(403).json({ error: 'Store access required' });
    }
    
    req.store = decoded;
    next();
  });
};

// Verify token endpoint (for checking if stored token is still valid)
router.get('/verify', (req, res) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ valid: false, error: 'No token provided' });
  }
  
  jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(401).json({ valid: false, error: 'Invalid or expired token' });
    }
    
    res.json({
      valid: true,
      type: decoded.type,
      expiresAt: new Date(decoded.exp * 1000)
    });
  });
});

module.exports = {
  router,
  authenticateOwner,
  authenticateStore
};
