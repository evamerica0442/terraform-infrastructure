const express = require('express');
const router = express.Router();
const db = require('../db/config');
const { authenticateToken, authorizeRole } = require('../middleware/auth');

// Get all stores for tenant
router.get('/', authenticateToken, async (req, res) => {
  try {
    const result = await db.queryWithTenant(
      'SELECT * FROM stores WHERE tenant_id = $1 AND is_active = true ORDER BY name',
      [req.user.tenantId],
      req.user.tenantId
    );
    
    res.json({
      success: true,
      stores: result.rows
    });
  } catch (error) {
    console.error('Error fetching stores:', error);
    res.status(500).json({ error: 'Failed to fetch stores' });
  }
});

// Get single store
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const result = await db.queryWithTenant(
      'SELECT * FROM stores WHERE id = $1 AND tenant_id = $2',
      [req.params.id, req.user.tenantId],
      req.user.tenantId
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Store not found' });
    }
    
    res.json({
      success: true,
      store: result.rows[0]
    });
  } catch (error) {
    console.error('Error fetching store:', error);
    res.status(500).json({ error: 'Failed to fetch store' });
  }
});

// Create new store (owner/manager only)
router.post('/', authenticateToken, authorizeRole('owner', 'manager'), async (req, res) => {
  const { name, address, phone } = req.body;
  
  if (!name) {
    return res.status(400).json({ error: 'Store name is required' });
  }
  
  try {
    const result = await db.queryWithTenant(
      `INSERT INTO stores (tenant_id, name, address, phone) 
       VALUES ($1, $2, $3, $4) 
       RETURNING *`,
      [req.user.tenantId, name, address, phone],
      req.user.tenantId
    );
    
    res.status(201).json({
      success: true,
      store: result.rows[0]
    });
  } catch (error) {
    console.error('Error creating store:', error);
    res.status(500).json({ error: 'Failed to create store' });
  }
});

// Update store
router.put('/:id', authenticateToken, authorizeRole('owner', 'manager'), async (req, res) => {
  const { name, address, phone, is_active } = req.body;
  
  try {
    const result = await db.queryWithTenant(
      `UPDATE stores 
       SET name = COALESCE($1, name),
           address = COALESCE($2, address),
           phone = COALESCE($3, phone),
           is_active = COALESCE($4, is_active),
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $5 AND tenant_id = $6
       RETURNING *`,
      [name, address, phone, is_active, req.params.id, req.user.tenantId],
      req.user.tenantId
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Store not found' });
    }
    
    res.json({
      success: true,
      store: result.rows[0]
    });
  } catch (error) {
    console.error('Error updating store:', error);
    res.status(500).json({ error: 'Failed to update store' });
  }
});

// Get store inventory
router.get('/:id/inventory', authenticateToken, async (req, res) => {
  try {
    const result = await db.queryWithTenant(
      `SELECT i.*, p.name, p.sku, p.selling_price, p.category
       FROM inventory i
       JOIN products p ON i.product_id = p.id
       WHERE i.store_id = $1 AND i.tenant_id = $2
       ORDER BY p.name`,
      [req.params.id, req.user.tenantId],
      req.user.tenantId
    );
    
    res.json({
      success: true,
      inventory: result.rows
    });
  } catch (error) {
    console.error('Error fetching inventory:', error);
    res.status(500).json({ error: 'Failed to fetch inventory' });
  }
});

module.exports = router;
