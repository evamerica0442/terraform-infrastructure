const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../db/config');
const { authenticateOwner } = require('./auth');

// All routes require owner authentication
router.use(authenticateOwner);

// Get all stores for owner
router.get('/', async (req, res) => {
  try {
    const result = await db.query(
      `SELECT 
        s.*,
        COUNT(DISTINCT t.id) as total_transactions,
        COALESCE(SUM(t.total_amount), 0) as total_sales,
        COUNT(DISTINCT i.product_id) as product_count
       FROM stores s
       LEFT JOIN transactions t ON s.id = t.store_id
       LEFT JOIN inventory i ON s.id = i.store_id
       WHERE s.owner_id = $1
       GROUP BY s.id
       ORDER BY s.created_at DESC`,
      [req.owner.ownerId]
    );
    
    res.json({
      success: true,
      stores: result.rows
    });
  } catch (error) {
    console.error('Error fetching stores:', error);
    res.status(500).json({ error: 'Failed to fetch stores' });
  }
});

// Get single store details with metrics
router.get('/:id', async (req, res) => {
  try {
    // Get store details
    const storeResult = await db.query(
      'SELECT * FROM stores WHERE id = $1 AND owner_id = $2',
      [req.params.id, req.owner.ownerId]
    );
    
    if (storeResult.rows.length === 0) {
      return res.status(404).json({ error: 'Store not found' });
    }
    
    // Get sales metrics
    const metricsResult = await db.query(
      `SELECT 
        COUNT(*) as transaction_count,
        COALESCE(SUM(total_amount), 0) as total_sales,
        COALESCE(AVG(total_amount), 0) as average_sale,
        COUNT(DISTINCT DATE(transaction_date)) as days_active
       FROM transactions
       WHERE store_id = $1`,
      [req.params.id]
    );
    
    // Get low stock items
    const lowStockResult = await db.query(
      `SELECT 
        p.name,
        p.sku,
        i.quantity,
        i.min_stock_level
       FROM inventory i
       JOIN products p ON i.product_id = p.id
       WHERE i.store_id = $1 AND i.quantity <= i.min_stock_level
       ORDER BY i.quantity ASC
       LIMIT 10`,
      [req.params.id]
    );
    
    res.json({
      success: true,
      store: storeResult.rows[0],
      metrics: metricsResult.rows[0],
      low_stock_items: lowStockResult.rows
    });
  } catch (error) {
    console.error('Error fetching store details:', error);
    res.status(500).json({ error: 'Failed to fetch store details' });
  }
});

// Create new store
router.post('/', async (req, res) => {
  const { store_name, address, phone, password } = req.body;
  
  if (!store_name || !password) {
    return res.status(400).json({ 
      error: 'Store name and password are required' 
    });
  }
  
  const client = await db.pool.connect();
  
  try {
    await client.query('BEGIN');
    
    // Generate store username
    const usernameResult = await client.query(
      'SELECT generate_store_username($1, $2) as username',
      [store_name, req.owner.ownerId]
    );
    const store_username = usernameResult.rows[0].username;
    
    // Hash password
    const salt = await bcrypt.genSalt(10);
    const store_password_hash = await bcrypt.hash(password, salt);
    
    // Create store
    const storeResult = await client.query(
      `INSERT INTO stores (owner_id, store_name, store_username, store_password_hash, address, phone)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [req.owner.ownerId, store_name, store_username, store_password_hash, address, phone]
    );
    
    const store = storeResult.rows[0];
    
    // Copy all products to inventory with 0 quantity
    await client.query(
      `INSERT INTO inventory (store_id, product_id, quantity, min_stock_level)
       SELECT $1, id, 0, 10
       FROM products
       WHERE owner_id = $2`,
      [store.id, req.owner.ownerId]
    );
    
    await client.query('COMMIT');
    
    res.status(201).json({
      success: true,
      message: 'Store created successfully',
      store: {
        id: store.id,
        name: store.store_name,
        username: store.store_username,
        address: store.address,
        phone: store.phone,
        created_at: store.created_at
      },
      credentials: {
        username: store.store_username,
        password: password // Return plaintext password only on creation
      }
    });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error creating store:', error);
    res.status(500).json({ error: 'Failed to create store' });
  } finally {
    client.release();
  }
});

// Update store
router.put('/:id', async (req, res) => {
  const { store_name, address, phone, is_active, new_password } = req.body;
  
  try {
    // Verify ownership
    const checkResult = await db.query(
      'SELECT id FROM stores WHERE id = $1 AND owner_id = $2',
      [req.params.id, req.owner.ownerId]
    );
    
    if (checkResult.rows.length === 0) {
      return res.status(404).json({ error: 'Store not found' });
    }
    
    let updateQuery = `
      UPDATE stores 
      SET store_name = COALESCE($1, store_name),
          address = COALESCE($2, address),
          phone = COALESCE($3, phone),
          is_active = COALESCE($4, is_active),
          updated_at = CURRENT_TIMESTAMP
    `;
    const params = [store_name, address, phone, is_active];
    
    // Handle password change
    if (new_password) {
      const salt = await bcrypt.genSalt(10);
      const store_password_hash = await bcrypt.hash(new_password, salt);
      updateQuery += `, store_password_hash = $${params.length + 1}`;
      params.push(store_password_hash);
    }
    
    updateQuery += ` WHERE id = $${params.length + 1} RETURNING *`;
    params.push(req.params.id);
    
    const result = await db.query(updateQuery, params);
    
    res.json({
      success: true,
      store: result.rows[0]
    });
  } catch (error) {
    console.error('Error updating store:', error);
    res.status(500).json({ error: 'Failed to update store' });
  }
});

// Delete store (soft delete)
router.delete('/:id', async (req, res) => {
  try {
    const result = await db.query(
      `UPDATE stores 
       SET is_active = false, updated_at = CURRENT_TIMESTAMP
       WHERE id = $1 AND owner_id = $2
       RETURNING id, store_name`,
      [req.params.id, req.owner.ownerId]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Store not found' });
    }
    
    res.json({
      success: true,
      message: `Store "${result.rows[0].store_name}" deactivated successfully`
    });
  } catch (error) {
    console.error('Error deleting store:', error);
    res.status(500).json({ error: 'Failed to delete store' });
  }
});

// Get sales data for a specific store (for owner dashboard)
router.get('/:id/sales', async (req, res) => {
  const { start_date, end_date, group_by = 'day' } = req.query;
  
  try {
    // Verify ownership
    const checkResult = await db.query(
      'SELECT id FROM stores WHERE id = $1 AND owner_id = $2',
      [req.params.id, req.owner.ownerId]
    );
    
    if (checkResult.rows.length === 0) {
      return res.status(404).json({ error: 'Store not found' });
    }
    
    let dateFormat;
    switch (group_by) {
      case 'hour':
        dateFormat = 'YYYY-MM-DD HH24:00';
        break;
      case 'week':
        dateFormat = 'IYYY-IW';
        break;
      case 'month':
        dateFormat = 'YYYY-MM';
        break;
      default:
        dateFormat = 'YYYY-MM-DD';
    }
    
    let query = `
      SELECT 
        TO_CHAR(transaction_date, $1) as period,
        COUNT(*) as transaction_count,
        SUM(total_amount) as total_sales,
        AVG(total_amount) as average_sale,
        MIN(total_amount) as min_sale,
        MAX(total_amount) as max_sale
      FROM transactions
      WHERE store_id = $2
    `;
    
    const params = [dateFormat, req.params.id];
    
    if (start_date) {
      params.push(start_date);
      query += ` AND transaction_date >= $${params.length}`;
    }
    
    if (end_date) {
      params.push(end_date);
      query += ` AND transaction_date <= $${params.length}`;
    }
    
    query += ` GROUP BY period ORDER BY period DESC LIMIT 100`;
    
    const result = await db.query(query, params);
    
    res.json({
      success: true,
      sales_data: result.rows
    });
  } catch (error) {
    console.error('Error fetching sales data:', error);
    res.status(500).json({ error: 'Failed to fetch sales data' });
  }
});

// Get top selling products for a store
router.get('/:id/top-products', async (req, res) => {
  const { limit = 10 } = req.query;
  
  try {
    // Verify ownership
    const checkResult = await db.query(
      'SELECT id FROM stores WHERE id = $1 AND owner_id = $2',
      [req.params.id, req.owner.ownerId]
    );
    
    if (checkResult.rows.length === 0) {
      return res.status(404).json({ error: 'Store not found' });
    }
    
    const result = await db.query(
      `SELECT 
        ti.product_id,
        ti.product_name,
        ti.product_sku,
        SUM(ti.quantity) as total_quantity_sold,
        COUNT(DISTINCT ti.transaction_id) as times_sold,
        SUM(ti.subtotal) as total_revenue
       FROM transaction_items ti
       JOIN transactions t ON ti.transaction_id = t.id
       WHERE t.store_id = $1
       GROUP BY ti.product_id, ti.product_name, ti.product_sku
       ORDER BY total_revenue DESC
       LIMIT $2`,
      [req.params.id, limit]
    );
    
    res.json({
      success: true,
      top_products: result.rows
    });
  } catch (error) {
    console.error('Error fetching top products:', error);
    res.status(500).json({ error: 'Failed to fetch top products' });
  }
});

module.exports = router;
