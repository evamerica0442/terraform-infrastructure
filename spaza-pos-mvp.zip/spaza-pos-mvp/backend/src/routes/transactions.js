const express = require('express');
const router = express.Router();
const db = require('../db/config');
const { authenticateToken } = require('../middleware/auth');

// Get transactions for a store
router.get('/store/:storeId', authenticateToken, async (req, res) => {
  const { storeId } = req.params;
  const { startDate, endDate, limit = 50 } = req.query;
  
  try {
    let query = `
      SELECT t.*, u.full_name as cashier_name
      FROM transactions t
      JOIN users u ON t.user_id = u.id
      WHERE t.store_id = $1 AND t.tenant_id = $2
    `;
    const params = [storeId, req.user.tenantId];
    
    if (startDate) {
      params.push(startDate);
      query += ` AND t.transaction_date >= $${params.length}`;
    }
    
    if (endDate) {
      params.push(endDate);
      query += ` AND t.transaction_date <= $${params.length}`;
    }
    
    query += ` ORDER BY t.transaction_date DESC LIMIT $${params.length + 1}`;
    params.push(limit);
    
    const result = await db.queryWithTenant(query, params, req.user.tenantId);
    
    res.json({
      success: true,
      transactions: result.rows
    });
  } catch (error) {
    console.error('Error fetching transactions:', error);
    res.status(500).json({ error: 'Failed to fetch transactions' });
  }
});

// Get single transaction with items
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const transactionResult = await db.queryWithTenant(
      `SELECT t.*, u.full_name as cashier_name, s.name as store_name
       FROM transactions t
       JOIN users u ON t.user_id = u.id
       JOIN stores s ON t.store_id = s.id
       WHERE t.id = $1 AND t.tenant_id = $2`,
      [req.params.id, req.user.tenantId],
      req.user.tenantId
    );
    
    if (transactionResult.rows.length === 0) {
      return res.status(404).json({ error: 'Transaction not found' });
    }
    
    const itemsResult = await db.queryWithTenant(
      `SELECT ti.*, p.name as product_name, p.sku
       FROM transaction_items ti
       JOIN products p ON ti.product_id = p.id
       WHERE ti.transaction_id = $1`,
      [req.params.id],
      req.user.tenantId
    );
    
    res.json({
      success: true,
      transaction: {
        ...transactionResult.rows[0],
        items: itemsResult.rows
      }
    });
  } catch (error) {
    console.error('Error fetching transaction:', error);
    res.status(500).json({ error: 'Failed to fetch transaction' });
  }
});

// Create transaction (supports offline sync)
router.post('/', authenticateToken, async (req, res) => {
  const { store_id, items, payment_method, total_amount, transaction_number, notes, offline_created_at } = req.body;
  
  if (!store_id || !items || items.length === 0) {
    return res.status(400).json({ error: 'Store ID and items are required' });
  }
  
  const client = await db.pool.connect();
  
  try {
    await client.query('BEGIN');
    await client.query(`SET LOCAL app.current_tenant_id = '${req.user.tenantId}'`);
    
    // Generate transaction number if not provided (offline transactions provide their own)
    const txnNumber = transaction_number || `TXN-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    // Insert transaction
    const transactionResult = await client.query(
      `INSERT INTO transactions (tenant_id, store_id, user_id, transaction_number, total_amount, payment_method, notes, is_synced, transaction_date)
       VALUES ($1, $2, $3, $4, $5, $6, $7, true, COALESCE($8, CURRENT_TIMESTAMP))
       RETURNING *`,
      [req.user.tenantId, store_id, req.user.userId, txnNumber, total_amount, payment_method, notes, offline_created_at]
    );
    
    const transactionId = transactionResult.rows[0].id;
    
    // Insert transaction items and update inventory
    for (const item of items) {
      // Insert item
      await client.query(
        `INSERT INTO transaction_items (transaction_id, product_id, quantity, unit_price, subtotal, discount)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [transactionId, item.product_id, item.quantity, item.unit_price, item.subtotal, item.discount || 0]
      );
      
      // Update inventory
      await client.query(
        `UPDATE inventory 
         SET quantity = quantity - $1,
             last_updated = CURRENT_TIMESTAMP
         WHERE store_id = $2 AND product_id = $3 AND tenant_id = $4`,
        [item.quantity, store_id, item.product_id, req.user.tenantId]
      );
    }
    
    await client.query('COMMIT');
    
    res.status(201).json({
      success: true,
      transaction: transactionResult.rows[0]
    });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error creating transaction:', error);
    res.status(500).json({ error: 'Failed to create transaction' });
  } finally {
    client.release();
  }
});

// Bulk sync endpoint for offline transactions
router.post('/sync/bulk', authenticateToken, async (req, res) => {
  const { transactions } = req.body;
  
  if (!Array.isArray(transactions) || transactions.length === 0) {
    return res.status(400).json({ error: 'Transactions array is required' });
  }
  
  const results = {
    success: [],
    failed: []
  };
  
  for (const txn of transactions) {
    try {
      const client = await db.pool.connect();
      
      try {
        await client.query('BEGIN');
        await client.query(`SET LOCAL app.current_tenant_id = '${req.user.tenantId}'`);
        
        // Check if transaction already exists
        const existing = await client.query(
          'SELECT id FROM transactions WHERE transaction_number = $1 AND tenant_id = $2',
          [txn.transaction_number, req.user.tenantId]
        );
        
        if (existing.rows.length > 0) {
          results.success.push({
            transaction_number: txn.transaction_number,
            status: 'already_synced',
            id: existing.rows[0].id
          });
          await client.query('COMMIT');
          continue;
        }
        
        // Insert transaction
        const transactionResult = await client.query(
          `INSERT INTO transactions (tenant_id, store_id, user_id, transaction_number, total_amount, payment_method, notes, is_synced, synced_at, transaction_date)
           VALUES ($1, $2, $3, $4, $5, $6, $7, true, CURRENT_TIMESTAMP, $8)
           RETURNING *`,
          [req.user.tenantId, txn.store_id, req.user.userId, txn.transaction_number, txn.total_amount, txn.payment_method, txn.notes, txn.transaction_date]
        );
        
        const transactionId = transactionResult.rows[0].id;
        
        // Insert items and update inventory
        for (const item of txn.items) {
          await client.query(
            `INSERT INTO transaction_items (transaction_id, product_id, quantity, unit_price, subtotal, discount)
             VALUES ($1, $2, $3, $4, $5, $6)`,
            [transactionId, item.product_id, item.quantity, item.unit_price, item.subtotal, item.discount || 0]
          );
          
          await client.query(
            `UPDATE inventory 
             SET quantity = quantity - $1,
                 last_updated = CURRENT_TIMESTAMP
             WHERE store_id = $2 AND product_id = $3 AND tenant_id = $4`,
            [item.quantity, txn.store_id, item.product_id, req.user.tenantId]
          );
        }
        
        await client.query('COMMIT');
        
        results.success.push({
          transaction_number: txn.transaction_number,
          status: 'synced',
          id: transactionId
        });
      } catch (error) {
        await client.query('ROLLBACK');
        throw error;
      } finally {
        client.release();
      }
    } catch (error) {
      console.error(`Failed to sync transaction ${txn.transaction_number}:`, error);
      results.failed.push({
        transaction_number: txn.transaction_number,
        error: error.message
      });
    }
  }
  
  res.json({
    success: true,
    results
  });
});

module.exports = router;
