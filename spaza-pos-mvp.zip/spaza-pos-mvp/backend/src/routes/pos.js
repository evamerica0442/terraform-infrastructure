const express = require('express');
const router = express.Router();
const db = require('../db/config');
const { authenticateStore } = require('./auth');

// All routes require store authentication
router.use(authenticateStore);

// Get products for POS (all products for this owner)
router.get('/products', async (req, res) => {
  try {
    const result = await db.query(
      `SELECT p.*
       FROM products p
       JOIN stores s ON p.owner_id = s.owner_id
       WHERE s.id = $1 AND p.is_active = true
       ORDER BY p.category, p.name`,
      [req.store.storeId]
    );
    
    res.json({
      success: true,
      products: result.rows
    });
  } catch (error) {
    console.error('Error fetching products:', error);
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});

// Get inventory for this specific store
router.get('/inventory', async (req, res) => {
  try {
    const result = await db.query(
      `SELECT 
        i.*,
        p.name,
        p.sku,
        p.barcode,
        p.selling_price,
        p.category
       FROM inventory i
       JOIN products p ON i.product_id = p.id
       WHERE i.store_id = $1
       ORDER BY p.category, p.name`,
      [req.store.storeId]
    );
    
    res.json({
      success: true,
      inventory: result.rows
    });
  } catch (error) {
    console.error('Error fetching inventory:', error);
    res.status(500).json({ error: 'Failed to fetch inventory' });
  }
});

// Sync transactions from POS (bulk endpoint)
router.post('/sync', async (req, res) => {
  const { transactions } = req.body;
  
  if (!Array.isArray(transactions) || transactions.length === 0) {
    return res.status(400).json({ error: 'Transactions array is required' });
  }
  
  const results = {
    synced: [],
    failed: []
  };
  
  for (const txn of transactions) {
    const client = await db.pool.connect();
    
    try {
      await client.query('BEGIN');
      
      // Check if transaction already exists (prevent duplicates)
      const existing = await client.query(
        'SELECT id FROM transactions WHERE transaction_number = $1',
        [txn.transaction_number]
      );
      
      if (existing.rows.length > 0) {
        results.synced.push({
          transaction_number: txn.transaction_number,
          status: 'already_synced',
          id: existing.rows[0].id
        });
        await client.query('COMMIT');
        client.release();
        continue;
      }
      
      // Insert transaction
      const transactionResult = await client.query(
        `INSERT INTO transactions (
          store_id, 
          staff_id,
          transaction_number, 
          total_amount, 
          payment_method, 
          notes, 
          transaction_date,
          client_created_at,
          is_synced, 
          synced_at
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, true, CURRENT_TIMESTAMP)
        RETURNING *`,
        [
          req.store.storeId,
          txn.staff_id || null,
          txn.transaction_number,
          txn.total_amount,
          txn.payment_method,
          txn.notes || '',
          txn.transaction_date,
          txn.transaction_date
        ]
      );
      
      const transactionId = transactionResult.rows[0].id;
      
      // Insert transaction items and update inventory
      for (const item of txn.items) {
        // Get product details for snapshot
        const productResult = await client.query(
          'SELECT name, sku FROM products WHERE id = $1',
          [item.product_id]
        );
        
        if (productResult.rows.length === 0) {
          throw new Error(`Product ${item.product_id} not found`);
        }
        
        const product = productResult.rows[0];
        
        // Insert transaction item
        await client.query(
          `INSERT INTO transaction_items (
            transaction_id, 
            product_id, 
            quantity, 
            unit_price, 
            subtotal, 
            discount,
            product_name,
            product_sku
          )
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
          [
            transactionId,
            item.product_id,
            item.quantity,
            item.unit_price,
            item.subtotal,
            item.discount || 0,
            product.name,
            product.sku
          ]
        );
        
        // Update inventory
        const updateResult = await client.query(
          `UPDATE inventory 
           SET quantity = quantity - $1,
               last_updated = CURRENT_TIMESTAMP
           WHERE store_id = $2 AND product_id = $3
           RETURNING quantity`,
          [item.quantity, req.store.storeId, item.product_id]
        );
        
        if (updateResult.rows.length === 0) {
          throw new Error(`Inventory not found for product ${item.product_id}`);
        }
        
        // Check for negative inventory (warning only, don't fail)
        if (updateResult.rows[0].quantity < 0) {
          console.warn(`⚠️ Negative inventory for product ${item.product_id}: ${updateResult.rows[0].quantity}`);
        }
      }
      
      await client.query('COMMIT');
      
      results.synced.push({
        transaction_number: txn.transaction_number,
        status: 'synced',
        id: transactionId
      });
      
    } catch (error) {
      await client.query('ROLLBACK');
      console.error(`Failed to sync transaction ${txn.transaction_number}:`, error);
      
      results.failed.push({
        transaction_number: txn.transaction_number,
        error: error.message
      });
    } finally {
      client.release();
    }
  }
  
  res.json({
    success: true,
    synced: results.synced,
    failed: results.failed
  });
});

// Get recent transactions for this store (for verification)
router.get('/transactions/recent', async (req, res) => {
  const { limit = 20 } = req.query;
  
  try {
    const result = await db.query(
      `SELECT 
        t.*,
        COALESCE(sf.staff_name, 'N/A') as staff_name,
        (
          SELECT json_agg(
            json_build_object(
              'product_name', ti.product_name,
              'quantity', ti.quantity,
              'unit_price', ti.unit_price,
              'subtotal', ti.subtotal
            )
          )
          FROM transaction_items ti
          WHERE ti.transaction_id = t.id
        ) as items
       FROM transactions t
       LEFT JOIN store_staff sf ON t.staff_id = sf.id
       WHERE t.store_id = $1
       ORDER BY t.transaction_date DESC
       LIMIT $2`,
      [req.store.storeId, limit]
    );
    
    res.json({
      success: true,
      transactions: result.rows
    });
  } catch (error) {
    console.error('Error fetching recent transactions:', error);
    res.status(500).json({ error: 'Failed to fetch transactions' });
  }
});

// Get today's sales summary
router.get('/sales/today', async (req, res) => {
  try {
    const result = await db.query(
      `SELECT 
        COUNT(*) as transaction_count,
        COALESCE(SUM(total_amount), 0) as total_sales,
        COALESCE(AVG(total_amount), 0) as average_sale,
        COUNT(CASE WHEN payment_method = 'cash' THEN 1 END) as cash_count,
        COUNT(CASE WHEN payment_method = 'card' THEN 1 END) as card_count,
        COUNT(CASE WHEN payment_method = 'mobile_money' THEN 1 END) as mobile_count
       FROM transactions
       WHERE store_id = $1 
         AND DATE(transaction_date) = CURRENT_DATE`,
      [req.store.storeId]
    );
    
    res.json({
      success: true,
      summary: result.rows[0]
    });
  } catch (error) {
    console.error('Error fetching today summary:', error);
    res.status(500).json({ error: 'Failed to fetch sales summary' });
  }
});

// Update inventory (stock adjustment from POS)
router.post('/inventory/adjust', async (req, res) => {
  const { product_id, quantity_change, reason, staff_id } = req.body;
  
  if (!product_id || !quantity_change) {
    return res.status(400).json({ 
      error: 'Product ID and quantity change are required' 
    });
  }
  
  const client = await db.pool.connect();
  
  try {
    await client.query('BEGIN');
    
    // Record adjustment
    await client.query(
      `INSERT INTO stock_adjustments (
        store_id, 
        product_id, 
        adjustment_type, 
        quantity_change, 
        reason,
        adjusted_by,
        synced_at
      )
      VALUES ($1, $2, $3, $4, $5, $6, CURRENT_TIMESTAMP)`,
      [
        req.store.storeId,
        product_id,
        reason || 'correction',
        quantity_change,
        reason,
        staff_id
      ]
    );
    
    // Update inventory
    const result = await client.query(
      `UPDATE inventory
       SET quantity = quantity + $1,
           last_updated = CURRENT_TIMESTAMP
       WHERE store_id = $2 AND product_id = $3
       RETURNING *`,
      [quantity_change, req.store.storeId, product_id]
    );
    
    if (result.rows.length === 0) {
      throw new Error('Inventory record not found');
    }
    
    await client.query('COMMIT');
    
    res.json({
      success: true,
      inventory: result.rows[0]
    });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error adjusting inventory:', error);
    res.status(500).json({ error: 'Failed to adjust inventory' });
  } finally {
    client.release();
  }
});

// Get low stock alerts for this store
router.get('/inventory/low-stock', async (req, res) => {
  try {
    const result = await db.query(
      `SELECT 
        i.*,
        p.name,
        p.sku,
        p.category
       FROM inventory i
       JOIN products p ON i.product_id = p.id
       WHERE i.store_id = $1 
         AND i.quantity <= i.min_stock_level
       ORDER BY i.quantity ASC`,
      [req.store.storeId]
    );
    
    res.json({
      success: true,
      low_stock_items: result.rows
    });
  } catch (error) {
    console.error('Error fetching low stock items:', error);
    res.status(500).json({ error: 'Failed to fetch low stock items' });
  }
});

module.exports = router;
