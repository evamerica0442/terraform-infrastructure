-- Enhanced Multitenant POS Database Schema
-- Supports Owner Portal + Individual Store POS Authentication

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Owners/Tenants table (Business owners who register on portal)
CREATE TABLE owners (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    business_name VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT true,
    subscription_tier VARCHAR(50) DEFAULT 'basic'
);

-- Stores table with individual authentication
-- Each store gets unique login credentials
CREATE TABLE stores (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_id UUID NOT NULL REFERENCES owners(id) ON DELETE CASCADE,
    store_name VARCHAR(255) NOT NULL,
    store_username VARCHAR(100) UNIQUE NOT NULL, -- Generated: storename_xxxxx
    store_password_hash VARCHAR(255) NOT NULL,
    address TEXT,
    phone VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT true,
    last_sync_at TIMESTAMP,
    
    -- Unique constraint: one store name per owner
    UNIQUE(owner_id, store_name)
);

-- Staff members (optional, for stores with multiple cashiers)
CREATE TABLE store_staff (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
    staff_name VARCHAR(255) NOT NULL,
    staff_code VARCHAR(50) NOT NULL, -- PIN or code for quick login
    role VARCHAR(50) DEFAULT 'cashier' CHECK (role IN ('manager', 'cashier')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT true,
    UNIQUE(store_id, staff_code)
);

-- Products table (managed by owner, shared across all stores)
CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_id UUID NOT NULL REFERENCES owners(id) ON DELETE CASCADE,
    sku VARCHAR(100),
    barcode VARCHAR(100),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    cost_price DECIMAL(10, 2) DEFAULT 0,
    selling_price DECIMAL(10, 2) NOT NULL,
    image_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT true,
    UNIQUE(owner_id, sku)
);

-- Inventory table (stock levels per store)
CREATE TABLE inventory (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
    product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    quantity DECIMAL(10, 2) DEFAULT 0,
    min_stock_level DECIMAL(10, 2) DEFAULT 0,
    max_stock_level DECIMAL(10, 2),
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(store_id, product_id)
);

-- Transactions table (sales from stores)
CREATE TABLE transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
    staff_id UUID REFERENCES store_staff(id), -- NULL if no staff system used
    transaction_number VARCHAR(100) UNIQUE NOT NULL, -- Client-generated for offline
    total_amount DECIMAL(10, 2) NOT NULL,
    payment_method VARCHAR(50) CHECK (payment_method IN ('cash', 'card', 'mobile_money', 'credit')),
    customer_name VARCHAR(255), -- Optional for credit sales
    transaction_date TIMESTAMP NOT NULL, -- Actual sale time (may be in past due to offline)
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- When record was created in DB
    synced_at TIMESTAMP, -- When this was synced from store
    is_synced BOOLEAN DEFAULT false,
    notes TEXT,
    
    -- Metadata for tracking offline transactions
    client_created_at TIMESTAMP, -- When created on store device
    sync_attempt_count INTEGER DEFAULT 0
);

-- Transaction items table
CREATE TABLE transaction_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    transaction_id UUID NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
    product_id UUID NOT NULL REFERENCES products(id),
    quantity DECIMAL(10, 2) NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    subtotal DECIMAL(10, 2) NOT NULL,
    discount DECIMAL(10, 2) DEFAULT 0,
    
    -- Product snapshot (in case product is deleted/changed)
    product_name VARCHAR(255) NOT NULL,
    product_sku VARCHAR(100)
);

-- Stock adjustments (inventory corrections, stock-takes, deliveries)
CREATE TABLE stock_adjustments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
    product_id UUID NOT NULL REFERENCES products(id),
    adjustment_type VARCHAR(50) CHECK (adjustment_type IN ('restock', 'correction', 'damage', 'theft', 'return')),
    quantity_change DECIMAL(10, 2) NOT NULL, -- Positive for additions, negative for removals
    reason TEXT,
    adjusted_by UUID REFERENCES store_staff(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    synced_at TIMESTAMP
);

-- Sync log (track sync operations)
CREATE TABLE sync_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
    sync_type VARCHAR(50) CHECK (sync_type IN ('transactions', 'inventory', 'products', 'full')),
    records_sent INTEGER,
    records_accepted INTEGER,
    records_rejected INTEGER,
    sync_started_at TIMESTAMP NOT NULL,
    sync_completed_at TIMESTAMP,
    status VARCHAR(50) CHECK (status IN ('success', 'partial', 'failed')),
    error_message TEXT
);

-- Indexes for performance
CREATE INDEX idx_stores_owner ON stores(owner_id);
CREATE INDEX idx_products_owner ON products(owner_id);
CREATE INDEX idx_inventory_store ON inventory(store_id);
CREATE INDEX idx_inventory_product ON inventory(product_id);
CREATE INDEX idx_transactions_store ON transactions(store_id);
CREATE INDEX idx_transactions_date ON transactions(transaction_date);
CREATE INDEX idx_transactions_sync ON transactions(is_synced, created_at) WHERE is_synced = false;
CREATE INDEX idx_transaction_items_txn ON transaction_items(transaction_id);
CREATE INDEX idx_staff_store ON store_staff(store_id);

-- Functions for business logic

-- Generate unique store username
CREATE OR REPLACE FUNCTION generate_store_username(p_store_name VARCHAR, p_owner_id UUID)
RETURNS VARCHAR AS $$
DECLARE
    base_username VARCHAR;
    final_username VARCHAR;
    counter INTEGER := 1;
BEGIN
    -- Create base username from store name (lowercase, no spaces, alphanumeric only)
    base_username := lower(regexp_replace(p_store_name, '[^a-zA-Z0-9]', '', 'g'));
    
    -- Ensure minimum length
    IF length(base_username) < 3 THEN
        base_username := base_username || '_store';
    END IF;
    
    -- Add random suffix for uniqueness
    final_username := base_username || '_' || substring(md5(random()::text) from 1 for 5);
    
    -- Ensure uniqueness
    WHILE EXISTS (SELECT 1 FROM stores WHERE store_username = final_username) LOOP
        final_username := base_username || '_' || substring(md5(random()::text) from 1 for 5);
        counter := counter + 1;
        IF counter > 10 THEN
            RAISE EXCEPTION 'Could not generate unique username after 10 attempts';
        END IF;
    END LOOP;
    
    RETURN final_username;
END;
$$ LANGUAGE plpgsql;

-- Update last_sync_at when transactions are synced
CREATE OR REPLACE FUNCTION update_store_last_sync()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE stores 
    SET last_sync_at = NEW.synced_at
    WHERE id = NEW.store_id AND NEW.synced_at IS NOT NULL;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_store_sync
    AFTER INSERT OR UPDATE ON transactions
    FOR EACH ROW
    WHEN (NEW.synced_at IS NOT NULL)
    EXECUTE FUNCTION update_store_last_sync();

-- Sample data function
CREATE OR REPLACE FUNCTION insert_sample_data()
RETURNS void AS $$
DECLARE
    owner_id UUID;
    store1_id UUID;
    store2_id UUID;
    product1_id UUID;
    product2_id UUID;
    store1_username VARCHAR;
    store2_username VARCHAR;
BEGIN
    -- Insert sample owner
    INSERT INTO owners (email, password_hash, full_name, business_name, phone)
    VALUES (
        'owner@spazachain.co.za',
        '$2a$10$8K1p/a0dL3LKkB/rBGK9C.uJ/h8HqPHh5rF5Y/5KvQ5Y0dWE8K5Ca', -- password123
        'Thabo Maseko',
        'Maseko Spaza Chain',
        '+27123456789'
    )
    RETURNING id INTO owner_id;
    
    -- Generate usernames for stores
    store1_username := generate_store_username('Soweto Main', owner_id);
    store2_username := generate_store_username('Alexandra Branch', owner_id);
    
    -- Insert sample stores
    INSERT INTO stores (owner_id, store_name, store_username, store_password_hash, address, phone)
    VALUES (
        owner_id,
        'Soweto Main Store',
        store1_username,
        '$2a$10$8K1p/a0dL3LKkB/rBGK9C.uJ/h8HqPHh5rF5Y/5KvQ5Y0dWE8K5Ca', -- password123
        '45 Vilakazi Street, Soweto, Johannesburg',
        '+27123456790'
    )
    RETURNING id INTO store1_id;
    
    INSERT INTO stores (owner_id, store_name, store_username, store_password_hash, address, phone)
    VALUES (
        owner_id,
        'Alexandra Branch',
        store2_username,
        '$2a$10$8K1p/a0dL3LKkB/rBGK9C.uJ/h8HqPHh5rF5Y/5KvQ5Y0dWE8K5Ca', -- password123
        '12 London Road, Alexandra, Johannesburg',
        '+27123456791'
    )
    RETURNING id INTO store2_id;
    
    -- Insert sample products
    INSERT INTO products (owner_id, sku, name, category, cost_price, selling_price)
    VALUES 
        (owner_id, 'BREAD001', 'White Bread', 'Bakery', 8.50, 12.00),
        (owner_id, 'MILK001', 'Fresh Milk 1L', 'Dairy', 12.00, 18.00),
        (owner_id, 'RICE001', 'Rice 2kg', 'Groceries', 25.00, 35.00),
        (owner_id, 'SUGAR001', 'White Sugar 2.5kg', 'Groceries', 28.00, 38.00),
        (owner_id, 'MAIZE001', 'Maize Meal 5kg', 'Groceries', 45.00, 60.00)
    RETURNING id INTO product1_id;
    
    -- Get product IDs for inventory
    SELECT id INTO product1_id FROM products WHERE sku = 'BREAD001' AND owner_id = owner_id;
    SELECT id INTO product2_id FROM products WHERE sku = 'MILK001' AND owner_id = owner_id;
    
    -- Insert sample inventory for store 1
    INSERT INTO inventory (store_id, product_id, quantity, min_stock_level)
    SELECT store1_id, id, 50, 10
    FROM products WHERE owner_id = owner_id;
    
    -- Insert sample inventory for store 2
    INSERT INTO inventory (store_id, product_id, quantity, min_stock_level)
    SELECT store2_id, id, 30, 10
    FROM products WHERE owner_id = owner_id;
    
    -- Output credentials
    RAISE NOTICE '=== SAMPLE DATA CREATED ===';
    RAISE NOTICE 'Owner Portal Login:';
    RAISE NOTICE '  Email: owner@spazachain.co.za';
    RAISE NOTICE '  Password: password123';
    RAISE NOTICE '';
    RAISE NOTICE 'Store 1 (Soweto Main) POS Login:';
    RAISE NOTICE '  Username: %', store1_username;
    RAISE NOTICE '  Password: password123';
    RAISE NOTICE '';
    RAISE NOTICE 'Store 2 (Alexandra Branch) POS Login:';
    RAISE NOTICE '  Username: %', store2_username;
    RAISE NOTICE '  Password: password123';
    
END;
$$ LANGUAGE plpgsql;
