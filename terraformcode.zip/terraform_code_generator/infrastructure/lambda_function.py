import json
import base64
import os
import boto3
from anthropic import Anthropic

# Initialize clients
s3_client = boto3.client('s3')
anthropic_client = Anthropic(api_key=os.environ['ANTHROPIC_API_KEY'])

BUCKET_NAME = os.environ.get('S3_BUCKET_NAME', 'terraform-claude-bucket')
CLAUDE_MODEL = "claude-sonnet-4-20250514"

def lambda_handler(event, context):
    """
    Main Lambda handler for processing Terraform and Architecture diagram operations
    """
    try:
        # Parse the request
        body = json.loads(event.get('body', '{}'))
        operation = body.get('operation')  # 'state_to_diagram' or 'diagram_to_terraform'
        
        if operation == 'state_to_diagram':
            return handle_state_to_diagram(body)
        elif operation == 'diagram_to_terraform':
            return handle_diagram_to_terraform(body)
        else:
            return create_response(400, {'error': 'Invalid operation. Use "state_to_diagram" or "diagram_to_terraform"'})
    
    except Exception as e:
        print(f"Error: {str(e)}")
        return create_response(500, {'error': str(e)})


def handle_state_to_diagram(body):
    """
    Process Terraform state file and generate architecture diagram
    """
    try:
        # Get the state file content (base64 encoded)
        state_content = body.get('file_content')
        if not state_content:
            return create_response(400, {'error': 'No state file content provided'})
        
        # Decode if base64 encoded
        try:
            state_json = base64.b64decode(state_content).decode('utf-8')
        except:
            # If not base64, assume it's already decoded
            state_json = state_content
        
        # Parse the state file
        state_data = json.loads(state_json)
        
        # Create prompt for Claude
        prompt = f"""I have a Terraform state file. Please analyze it and create a visual architecture diagram using Mermaid syntax that shows:

1. All AWS resources and their relationships
2. Network topology (VPC, subnets, etc.)
3. Security groups and their rules
4. EC2 instances, databases, load balancers, etc.
5. Data flow between components

Here is the Terraform state file:

```json
{json.dumps(state_data, indent=2)}
```

Please provide:
1. A Mermaid diagram showing the architecture
2. A text description of the infrastructure
3. A summary of key resources and their purposes

Format your response as JSON with these keys:
- mermaid_diagram: The Mermaid syntax
- description: Text description
- resources_summary: List of key resources
"""

        # Call Claude API
        response = anthropic_client.messages.create(
            model=CLAUDE_MODEL,
            max_tokens=4096,
            messages=[
                {"role": "user", "content": prompt}
            ]
        )
        
        # Extract the response
        claude_response = response.content[0].text
        
        # Try to parse as JSON, otherwise return as text
        try:
            result = json.loads(claude_response)
        except:
            result = {
                "mermaid_diagram": claude_response,
                "description": "See diagram above",
                "resources_summary": "Parse the response for details"
            }
        
        return create_response(200, {
            'success': True,
            'operation': 'state_to_diagram',
            'result': result
        })
    
    except Exception as e:
        print(f"Error in state_to_diagram: {str(e)}")
        return create_response(500, {'error': str(e)})


def handle_diagram_to_terraform(body):
    """
    Process architecture diagram and generate Terraform files
    """
    try:
        # Get the diagram image (base64 encoded)
        image_content = body.get('file_content')
        image_type = body.get('image_type', 'image/png')
        
        if not image_content:
            return create_response(400, {'error': 'No diagram image provided'})
        
        # Remove data URL prefix if present
        if ',' in image_content and 'base64' in image_content:
            image_content = image_content.split(',')[1]
        
        # Create prompt for Claude with image
        prompt = """Please analyze this AWS architecture diagram and generate complete Terraform files to build this infrastructure.

Your response should include:

1. **main.tf** - Main Terraform configuration with all resources
2. **variables.tf** - Input variables
3. **outputs.tf** - Output values
4. **terraform.tfvars.example** - Example variable values
5. **README.md** - Deployment instructions

Please provide the response as a JSON object with this structure:
```json
{
  "files": {
    "main.tf": "content here",
    "variables.tf": "content here",
    "outputs.tf": "content here",
    "terraform.tfvars.example": "content here",
    "README.md": "content here"
  },
  "description": "Brief description of the infrastructure",
  "resources": ["list", "of", "main", "resources"]
}
```

Make sure to:
- Include all resources shown in the diagram
- Use appropriate AWS resource types
- Add proper dependencies between resources
- Include security best practices
- Add helpful comments
- Make variables configurable where appropriate"""

        # Call Claude API with image
        response = anthropic_client.messages.create(
            model=CLAUDE_MODEL,
            max_tokens=8000,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": image_type,
                                "data": image_content
                            }
                        },
                        {
                            "type": "text",
                            "text": prompt
                        }
                    ]
                }
            ]
        )
        
        # Extract the response
        claude_response = response.content[0].text
        
        # Try to parse as JSON
        try:
            # Remove markdown code blocks if present
            if '```json' in claude_response:
                claude_response = claude_response.split('```json')[1].split('```')[0].strip()
            elif '```' in claude_response:
                claude_response = claude_response.split('```')[1].split('```')[0].strip()
            
            result = json.loads(claude_response)
        except Exception as parse_error:
            print(f"JSON parse error: {str(parse_error)}")
            # If parsing fails, return raw response
            result = {
                "files": {
                    "main.tf": claude_response
                },
                "description": "Generated Terraform configuration",
                "resources": []
            }
        
        # Save files to S3 if bucket is configured
        if BUCKET_NAME:
            try:
                save_files_to_s3(result.get('files', {}))
            except Exception as s3_error:
                print(f"S3 save error: {str(s3_error)}")
        
        return create_response(200, {
            'success': True,
            'operation': 'diagram_to_terraform',
            'result': result
        })
    
    except Exception as e:
        print(f"Error in diagram_to_terraform: {str(e)}")
        return create_response(500, {'error': str(e)})


def save_files_to_s3(files):
    """
    Save generated Terraform files to S3
    """
    import datetime
    timestamp = datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
    
    for filename, content in files.items():
        s3_key = f"generated/{timestamp}/{filename}"
        s3_client.put_object(
            Bucket=BUCKET_NAME,
            Key=s3_key,
            Body=content.encode('utf-8'),
            ContentType='text/plain'
        )
        print(f"Saved {filename} to S3: {s3_key}")


def create_response(status_code, body):
    """
    Create HTTP response with CORS headers
    """
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
        },
        'body': json.dumps(body)
    }
