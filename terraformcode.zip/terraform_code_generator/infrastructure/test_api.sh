#!/bin/bash

# Terraform Claude AI Assistant - Test Script
# This script tests the deployed API endpoints

echo "╔════════════════════════════════════════════════════╗"
echo "║  Terraform AI Assistant - API Test Script         ║"
echo "╚════════════════════════════════════════════════════╝"
echo ""

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_info() {
    echo -e "${NC}ℹ $1${NC}"
}

# Get API endpoint from Terraform
cd infrastructure
API_ENDPOINT=$(terraform output -raw api_endpoint 2>/dev/null)

if [ -z "$API_ENDPOINT" ]; then
    print_error "Could not retrieve API endpoint. Is the infrastructure deployed?"
    exit 1
fi

print_info "Testing API endpoint: $API_ENDPOINT"
echo ""

# Test 1: State to Diagram (with minimal test data)
echo "Test 1: State to Diagram"
echo "------------------------"

# Create a minimal test state file
TEST_STATE='{
  "version": 4,
  "terraform_version": "1.0.0",
  "resources": [
    {
      "type": "aws_vpc",
      "name": "main",
      "provider": "provider[\"registry.terraform.io/hashicorp/aws\"]",
      "instances": [
        {
          "attributes": {
            "id": "vpc-12345",
            "cidr_block": "10.0.0.0/16"
          }
        }
      ]
    }
  ]
}'

# Encode to base64
ENCODED_STATE=$(echo "$TEST_STATE" | base64)

# Make API call
RESPONSE=$(curl -s -X POST "$API_ENDPOINT" \
  -H "Content-Type: application/json" \
  -d "{
    \"operation\": \"state_to_diagram\",
    \"file_content\": \"$ENCODED_STATE\"
  }")

# Check response
if echo "$RESPONSE" | grep -q "success"; then
    print_success "State to Diagram API is working"
else
    print_error "State to Diagram API failed"
    echo "Response: $RESPONSE"
fi

echo ""

# Test 2: Invalid operation
echo "Test 2: Error Handling"
echo "---------------------"

RESPONSE=$(curl -s -X POST "$API_ENDPOINT" \
  -H "Content-Type: application/json" \
  -d '{"operation": "invalid_operation"}')

if echo "$RESPONSE" | grep -q "error"; then
    print_success "Error handling is working correctly"
else
    print_error "Error handling test failed"
fi

echo ""

# Test 3: CORS headers
echo "Test 3: CORS Headers"
echo "-------------------"

CORS_RESPONSE=$(curl -s -I -X OPTIONS "$API_ENDPOINT" \
  -H "Origin: http://example.com" \
  -H "Access-Control-Request-Method: POST")

if echo "$CORS_RESPONSE" | grep -qi "access-control-allow-origin"; then
    print_success "CORS headers are configured"
else
    print_error "CORS headers are missing"
fi

echo ""
echo "╔════════════════════════════════════════════════════╗"
echo "║              Testing Complete                      ║"
echo "╚════════════════════════════════════════════════════╝"
echo ""
print_info "API Endpoint: $API_ENDPOINT"
print_info "Web Interface: $(terraform output -raw web_hosting_url)"
echo ""
