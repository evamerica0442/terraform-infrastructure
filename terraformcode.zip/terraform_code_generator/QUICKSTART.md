# 🚀 QUICK START GUIDE

Get your Terraform AI Assistant running in 5 minutes!

## Prerequisites Checklist

- [ ] AWS Account with credentials configured (`aws configure`)
- [ ] Terraform installed (>= 1.0)
- [ ] Python 3.11+ installed
- [ ] Anthropic API key ([Get one here](https://console.anthropic.com/))

## Installation Steps

### 1. Configure API Key (30 seconds)

```bash
cd infrastructure
cp terraform.tfvars.example terraform.tfvars
nano terraform.tfvars  # Add your Anthropic API key
```

Replace `sk-ant-api03-...` with your actual API key.

### 2. Deploy (2-3 minutes)

**Option A: Automated (Recommended)**
```bash
./deploy.sh
```

**Option B: Manual**
```bash
cd infrastructure
terraform init
terraform apply -auto-approve
```

### 3. Update Frontend (30 seconds)

```bash
# Get your API endpoint
cd infrastructure
API_ENDPOINT=$(terraform output -raw api_endpoint)

# Update and upload index.html
cd ..
sed "s|YOUR_API_GATEWAY_URL_HERE|$API_ENDPOINT|g" index.html > index_updated.html
aws s3 cp index_updated.html s3://$(terraform output -raw web_hosting_bucket)/index.html --content-type "text/html"
```

### 4. Access Your Application

```bash
# Get the web URL
cd infrastructure
terraform output web_hosting_url
```

Visit the URL in your browser! 🎉

## What You Can Do

✅ **Upload a Terraform state file** → Get an architecture diagram  
✅ **Upload an architecture diagram** → Get Terraform files

## Example Test

Try it with the included example state file:

1. Open your web application
2. Click "State → Diagram"
3. Upload `example_state.tfstate`
4. Click "Generate Diagram"

## Cost Estimate

- AWS: < $5/month for moderate use
- Claude API: ~$0.03 per diagram/generation

## Need Help?

- 📖 Full documentation: See `README.md`
- 🧪 Test API: Run `./test_api.sh`
- 🗑️ Clean up: Run `./destroy.sh`

## Common Issues

**"InvalidKeyPair.NotFound"**  
→ You don't need an SSH key for this project

**"ANTHROPIC_API_KEY not set"**  
→ Add your API key to `infrastructure/terraform.tfvars`

**Web page can't connect to API**  
→ Make sure you updated `index.html` with your API endpoint

**Lambda timeout errors**  
→ Normal for first request (cold start). Try again.

---

**🎯 Pro Tip**: Star this project and share it with your team!
