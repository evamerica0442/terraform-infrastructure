# Terraform AI Assistant - Powered by Claude

An intelligent web application that uses Claude AI to convert between Terraform state files and AWS architecture diagrams, and vice versa.

## 🎯 Features

### 1. **State → Diagram**
Upload a Terraform state file (`.tfstate`) and automatically generate:
- Interactive Mermaid architecture diagrams
- Detailed infrastructure description
- Resource inventory and relationships

### 2. **Diagram → Terraform**
Upload an AWS architecture diagram (PNG/JPG) and automatically generate:
- Complete Terraform configuration files (`main.tf`)
- Variable definitions (`variables.tf`)
- Output configurations (`outputs.tf`)
- Example variable values (`terraform.tfvars.example`)
- Deployment documentation (`README.md`)

## 🏗️ Architecture

```
┌─────────────────┐
│   Web Frontend  │ (S3 Static Website)
│   (HTML/JS)     │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  API Gateway    │ (REST API)
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Lambda Function │ ──────► Anthropic Claude API
│  (Python 3.12)  │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│   S3 Bucket     │ (Generated Files Storage)
└─────────────────┘
```

## 📋 Prerequisites

1. **AWS Account** with appropriate permissions
2. **Terraform** (>= 1.0) installed
3. **AWS CLI** configured with credentials
4. **Anthropic API Key** - Get one at [Anthropic Console](https://console.anthropic.com/)
5. **Python 3.11+** (for local testing)
6. **pip** (Python package manager)

## 🚀 Quick Start

### Step 1: Clone and Setup

```bash
# Navigate to the infrastructure directory
cd infrastructure

# Copy the example tfvars file
cp terraform.tfvars.example terraform.tfvars

# Edit terraform.tfvars and add your Anthropic API key
nano terraform.tfvars
```

### Step 2: Configure AWS Credentials

```bash
aws configure
# Or set environment variables:
export AWS_ACCESS_KEY_ID="your_access_key"
export AWS_SECRET_ACCESS_KEY="your_secret_key"
export AWS_DEFAULT_REGION="us-east-1"
```

### Step 3: Deploy Infrastructure

```bash
# Initialize Terraform
terraform init

# Review the deployment plan
terraform plan

# Deploy (this may take 2-3 minutes)
terraform apply -auto-approve
```

### Step 4: Update Web Frontend

After deployment, Terraform outputs the API Gateway URL. Update the frontend:

1. Note the API endpoint from Terraform output
2. Open `index.html`
3. Find this line: `const API_ENDPOINT = 'YOUR_API_GATEWAY_URL_HERE/process';`
4. Replace it with your actual endpoint
5. Re-upload to S3:

```bash
# Get the bucket name from Terraform output
WEB_BUCKET=$(terraform output -raw web_hosting_bucket)

# Upload updated index.html
aws s3 cp ../index.html s3://$WEB_BUCKET/index.html --content-type "text/html"
```

### Step 5: Access Your Application

```bash
# Get the website URL
terraform output web_hosting_url
```

Visit the URL in your browser!

## 📁 Project Structure

```
.
├── lambda_function.py          # Main Lambda function code
├── index.html                  # Web frontend interface
├── infrastructure/
│   ├── main.tf                 # Terraform infrastructure
│   ├── variables.tf            # Input variables
│   ├── outputs.tf              # Output values
│   ├── requirements.txt        # Python dependencies
│   └── terraform.tfvars.example # Example configuration
└── README.md                   # This file
```

## 🔧 Configuration

### Environment Variables (Lambda)

The Lambda function uses these environment variables:

- `ANTHROPIC_API_KEY` - Your Anthropic API key (required)
- `S3_BUCKET_NAME` - S3 bucket for storing generated files (auto-configured)

### Terraform Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `aws_region` | AWS region to deploy | `us-east-1` |
| `project_name` | Project name for resources | `terraform-claude-assistant` |
| `environment` | Environment (dev/staging/prod) | `dev` |
| `anthropic_api_key` | Anthropic API key | (required) |
| `api_stage_name` | API Gateway stage | `prod` |

## 📖 Usage Examples

### Using the Web Interface

1. **Generate Diagram from State**:
   - Click "State → Diagram" card
   - Upload your `terraform.tfstate` file
   - Click "Generate Diagram"
   - View the interactive Mermaid diagram

2. **Generate Terraform from Diagram**:
   - Click "Diagram → Terraform" card
   - Upload your architecture diagram (PNG/JPG)
   - Click "Generate Terraform Files"
   - Download individual files or all files

### Using the API Directly

#### State to Diagram

```bash
# Encode your state file to base64
STATE_CONTENT=$(cat terraform.tfstate | base64)

# Call the API
curl -X POST https://your-api-gateway-url/prod/process \
  -H "Content-Type: application/json" \
  -d "{
    \"operation\": \"state_to_diagram\",
    \"file_content\": \"$STATE_CONTENT\"
  }"
```

#### Diagram to Terraform

```bash
# Encode your image to base64
IMAGE_CONTENT=$(cat architecture.png | base64)

# Call the API
curl -X POST https://your-api-gateway-url/prod/process \
  -H "Content-Type: application/json" \
  -d "{
    \"operation\": \"diagram_to_terraform\",
    \"file_content\": \"$IMAGE_CONTENT\",
    \"image_type\": \"image/png\"
  }"
```

## 💰 Cost Estimation

### AWS Resources (Monthly)

- **Lambda**: ~$0.20 for 1,000 requests (512MB, 30s avg)
- **API Gateway**: ~$3.50 for 1M requests
- **S3 Storage**: ~$0.023/GB
- **S3 Requests**: ~$0.0004/1,000 requests
- **Data Transfer**: First 1GB free, then $0.09/GB

**Estimated Total**: < $5/month for moderate use

### Claude API Costs

- **Claude Sonnet 4**: ~$3 per million input tokens
- **Typical request**: ~10,000 tokens ($0.03)
- **100 requests/day**: ~$90/month

💡 **Free Tier**: AWS Lambda includes 1M free requests/month

## 🔒 Security Best Practices

1. **API Key Security**:
   - Never commit API keys to version control
   - Use AWS Secrets Manager for production
   - Rotate keys regularly

2. **S3 Bucket Security**:
   - Generated files bucket is private by default
   - Web hosting bucket has public read-only access
   - Enable versioning for recovery

3. **API Gateway**:
   - Consider adding API key authentication
   - Set up rate limiting for production
   - Enable CloudWatch logging

4. **Lambda**:
   - Uses least-privilege IAM roles
   - Timeout set to 5 minutes max
   - Logs are retained for 7 days

### Implementing Additional Security

```hcl
# Add API key requirement (in main.tf)
resource "aws_api_gateway_api_key" "api_key" {
  name = "${var.project_name}-api-key"
}

resource "aws_api_gateway_usage_plan" "usage_plan" {
  name = "${var.project_name}-usage-plan"

  api_stages {
    api_id = aws_api_gateway_rest_api.api.id
    stage  = aws_api_gateway_stage.api_stage.stage_name
  }
}
```

## 🧪 Testing

### Test Lambda Locally

```bash
# Install dependencies
pip install -r infrastructure/requirements.txt

# Set environment variables
export ANTHROPIC_API_KEY="your-key"
export S3_BUCKET_NAME="test-bucket"

# Run Python interactively
python3
>>> from lambda_function import lambda_handler
>>> # Test with sample events
```

### Test API Endpoint

```bash
# Health check
curl https://your-api-url/prod/process

# Test with minimal payload
curl -X POST https://your-api-url/prod/process \
  -H "Content-Type: application/json" \
  -d '{"operation":"state_to_diagram","file_content":"e30="}'
```

## 🐛 Troubleshooting

### Issue: "ANTHROPIC_API_KEY not set"
**Solution**: Make sure you've added your API key to `terraform.tfvars`

### Issue: Lambda timeout
**Solution**: Increase timeout in `main.tf` (default is 300s)

### Issue: CORS errors in browser
**Solution**: Verify API Gateway OPTIONS method is configured correctly

### Issue: Cannot access website
**Solution**: Check S3 bucket policy allows public read access

### Issue: Files not appearing in S3
**Solution**: Check Lambda IAM role has S3 write permissions

## 📊 Monitoring

### CloudWatch Logs

```bash
# View Lambda logs
aws logs tail /aws/lambda/terraform-claude-assistant-function --follow

# View API Gateway logs
aws logs tail API-Gateway-Execution-Logs_<api-id>/prod --follow
```

### Metrics to Monitor

- Lambda invocations and errors
- Lambda duration (to optimize costs)
- API Gateway 4xx/5xx errors
- S3 storage usage

## 🔄 Updates and Maintenance

### Update Lambda Code

```bash
# After modifying lambda_function.py
cd infrastructure
terraform apply -auto-approve
```

### Update Web Frontend

```bash
# After modifying index.html
WEB_BUCKET=$(terraform output -raw web_hosting_bucket)
aws s3 cp ../index.html s3://$WEB_BUCKET/index.html
```

### Update Dependencies

```bash
# Edit requirements.txt, then
terraform apply -replace="null_resource.create_lambda_layer"
```

## 🧹 Cleanup

To destroy all resources and avoid charges:

```bash
cd infrastructure
terraform destroy -auto-approve
```

⚠️ **Warning**: This will delete all resources including generated files in S3.

## 🤝 Contributing

Contributions welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is provided as-is for educational and commercial use.

## 🆘 Support

For issues or questions:
- AWS Documentation: https://docs.aws.amazon.com/
- Terraform Documentation: https://www.terraform.io/docs
- Anthropic Documentation: https://docs.anthropic.com/
- Claude API Reference: https://docs.anthropic.com/claude/reference

## 🎉 Acknowledgments

- Built with [Claude AI](https://www.anthropic.com/) by Anthropic
- Infrastructure powered by AWS Lambda and API Gateway
- Diagrams rendered with [Mermaid.js](https://mermaid.js.org/)

---

**Made with ❤️ using Claude AI**
