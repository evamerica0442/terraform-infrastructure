#!/bin/bash

# Terraform Claude AI Assistant - Deployment Script
# This script automates the deployment process

set -e  # Exit on error

echo "╔════════════════════════════════════════════════════╗"
echo "║  Terraform AI Assistant - Deployment Script        ║"
echo "║  Powered by Claude AI                              ║"
echo "╚════════════════════════════════════════════════════╝"
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_info() {
    echo -e "${NC}ℹ $1${NC}"
}

# Check prerequisites
echo "Step 1: Checking prerequisites..."
echo "--------------------------------"

# Check for Terraform
if ! command -v terraform &> /dev/null; then
    print_error "Terraform is not installed. Please install Terraform first."
    exit 1
fi
print_success "Terraform is installed: $(terraform version | head -n1)"

# Check for AWS CLI
if ! command -v aws &> /dev/null; then
    print_error "AWS CLI is not installed. Please install AWS CLI first."
    exit 1
fi
print_success "AWS CLI is installed: $(aws --version)"

# Check for Python
if ! command -v python3 &> /dev/null; then
    print_error "Python 3 is not installed. Please install Python 3 first."
    exit 1
fi
print_success "Python 3 is installed: $(python3 --version)"

# Check AWS credentials
if ! aws sts get-caller-identity &> /dev/null; then
    print_error "AWS credentials are not configured. Run 'aws configure' first."
    exit 1
fi
print_success "AWS credentials are configured"

echo ""
echo "Step 2: Setting up configuration..."
echo "-----------------------------------"

# Check if terraform.tfvars exists
cd infrastructure
if [ ! -f "terraform.tfvars" ]; then
    print_warning "terraform.tfvars not found. Creating from example..."
    cp terraform.tfvars.example terraform.tfvars
    
    echo ""
    print_warning "IMPORTANT: Please edit terraform.tfvars and add your Anthropic API key"
    print_info "Get your API key from: https://console.anthropic.com/"
    echo ""
    read -p "Press Enter after you've added your API key to terraform.tfvars..."
fi

# Validate that API key is set
if grep -q "sk-ant-api03-..." terraform.tfvars; then
    print_error "Please replace the placeholder API key in terraform.tfvars with your actual key"
    exit 1
fi

print_success "Configuration file is ready"

echo ""
echo "Step 3: Installing Python dependencies..."
echo "-----------------------------------------"

# Create a temporary directory for dependencies
mkdir -p /tmp/terraform-assistant-deps
pip install -r requirements.txt -t /tmp/terraform-assistant-deps --quiet
print_success "Python dependencies installed"

echo ""
echo "Step 4: Initializing Terraform..."
echo "---------------------------------"

terraform init
print_success "Terraform initialized"

echo ""
echo "Step 5: Validating Terraform configuration..."
echo "---------------------------------------------"

terraform validate
print_success "Terraform configuration is valid"

echo ""
echo "Step 6: Planning deployment..."
echo "-----------------------------"

terraform plan -out=tfplan
print_success "Terraform plan created"

echo ""
echo "Step 7: Deploying infrastructure..."
echo "-----------------------------------"
print_warning "This will create AWS resources that may incur costs."
read -p "Do you want to proceed with deployment? (yes/no): " -r
echo

if [[ ! $REPLY =~ ^[Yy]es$ ]]; then
    print_info "Deployment cancelled by user"
    exit 0
fi

terraform apply tfplan
print_success "Infrastructure deployed successfully!"

echo ""
echo "Step 8: Retrieving outputs..."
echo "----------------------------"

# Get outputs
API_ENDPOINT=$(terraform output -raw api_endpoint)
WEB_URL=$(terraform output -raw web_hosting_url)
WEB_BUCKET=$(terraform output -raw web_hosting_bucket)

print_success "API Endpoint: $API_ENDPOINT"
print_success "Web URL: $WEB_URL"

echo ""
echo "Step 9: Updating web frontend..."
echo "--------------------------------"

# Update index.html with API endpoint
cd ..
sed "s|YOUR_API_GATEWAY_URL_HERE|$API_ENDPOINT|g" index.html > index_updated.html

# Upload to S3
aws s3 cp index_updated.html s3://$WEB_BUCKET/index.html --content-type "text/html"
rm index_updated.html

print_success "Web frontend updated and uploaded to S3"

echo ""
echo "╔════════════════════════════════════════════════════╗"
echo "║           DEPLOYMENT COMPLETED!                     ║"
echo "╚════════════════════════════════════════════════════╝"
echo ""
print_success "Your Terraform AI Assistant is ready!"
echo ""
print_info "Access your application at:"
echo "  🌐 $WEB_URL"
echo ""
print_info "API Endpoint:"
echo "  🔌 $API_ENDPOINT"
echo ""
print_info "What you can do now:"
echo "  1. Upload a Terraform state file to generate diagrams"
echo "  2. Upload an architecture diagram to generate Terraform code"
echo "  3. Monitor Lambda logs in CloudWatch"
echo ""
print_warning "Remember: This application uses the Claude API which incurs costs"
print_info "Monitor your usage at: https://console.anthropic.com/"
echo ""
print_info "To destroy all resources later, run:"
echo "  cd infrastructure && terraform destroy"
echo ""
